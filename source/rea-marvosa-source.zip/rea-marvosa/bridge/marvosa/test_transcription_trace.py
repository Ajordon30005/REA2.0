"""Integrity/publication failure controls for complete trace transport."""
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from transcription.trace import pack, unpack, TraceBuffer


class TraceIntegrityTests(unittest.TestCase):
    def test_live_word_preserves_every_native_generator_across_snapshots(self):
        from native_ai import load_native_ai
        load_native_ai()
        from hcl_engine import HCLTranscriber
        original, streamed = HCLTranscriber(), HCLTranscriber()
        streamed.braid_log = TraceBuffer("generator")
        for round in range(2):
            for method, arguments in (("add", (137, -72)), ("mul", (10**40, 23)),
                                      ("neg", (99,)), ("sqrt", (2*10**40,)), ("pow_int", (2*10**40, 7))):
                self.assertEqual(getattr(original, method)(*arguments), getattr(streamed, method)(*arguments))
            snapshot = streamed.braid_log.packed()
            expected = [{"operation": item["op"], "phase_fraction": str(item["r"].phase_frac),
                         "amplitude": str(item["r"].amp)} for item in original.braid_log]
            self.assertEqual(list(unpack(snapshot)), expected)
            self.assertEqual(snapshot, pack(expected, "generator"))
            self.assertEqual(len(streamed.braid_log), len(original.braid_log))
        self.assertEqual([(v["op"], v["r"].amp) for v in streamed.braid_log],
                         [(v["op"], v["r"].amp) for v in original.braid_log])
        streamed.clear()
        self.assertEqual(list(unpack(streamed.braid_log.packed())), [])
        self.assertEqual(streamed.braid_len, original.braid_len)

    def test_complete_stream_rejects_changed_digest_count_and_length(self):
        trace = pack([{"operation": "COMP[+]", "phase_fraction": "0", "amplitude": "123"}], "generator")
        for key, value in (("sha256", "0" * 64), ("record_count", 0), ("uncompressed_bytes", 0)):
            with self.subTest(key=key), self.assertRaises(ValueError):
                list(unpack({**trace, key: value}))

    def test_public_extractor_does_not_publish_unverified_output(self):
        trace = pack([{"source": "module:1", "start": 0, "end": 1}], "source")
        trace["sha256"] = "0" * 64
        with tempfile.TemporaryDirectory() as directory:
            source, target = Path(directory) / "report.json", Path(directory) / "word.jsonl"
            source.write_text(json.dumps({"execution": {"braid_sources": trace}}))
            process = subprocess.run([sys.executable, str(Path(__file__).resolve().parents[2] / "scripts/hcl-braid.py"),
                                      str(source), "--sources", "--output", str(target)], capture_output=True)
            self.assertNotEqual(process.returncode, 0)
            self.assertIn(b"digest/count/length mismatch", process.stderr)
            self.assertFalse(target.exists())


if __name__ == "__main__":
    unittest.main()
