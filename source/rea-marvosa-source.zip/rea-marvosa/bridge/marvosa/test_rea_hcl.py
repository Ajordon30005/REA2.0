"""Production-engine regressions; no simulated HCL arithmetic or recall."""
import concurrent.futures
import hashlib
import json
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parent))
import rea_hcl as hcl


class HclIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.case = str(Path(self.temp.name) / "case")

    def call(self, operation, **kwargs):
        return hcl.dispatch({"operation": operation, "input": kwargs})

    def remember(self, text="SQLite search", source="search", case=None, **extra):
        raw = json.dumps({"operation": "inspect", "confidence": "observed",
                          "normalized_result": {"text": text}, **extra}, ensure_ascii=False)
        result = self.call("hcl_remember_evidence", case_path=case or self.case,
                           entries=[{"source": source, "raw_json": raw}])
        return raw, result

    def test_original_engines_match_pinned_source(self):
        root = Path(hcl.__file__).parent
        manifest = json.loads((root / "UPSTREAM.json").read_text())
        for file, expected in manifest["marvosa"]["files_sha256"].items():
            self.assertEqual(hashlib.sha256((root / "vendor" / file).read_bytes()).hexdigest(), expected)

    def test_decimal_literals_do_not_round_through_binary_float(self):
        result = self.call("hcl_calculate", expression="0.1 + 0.2")
        self.assertEqual(result["value_integer"], str(3 * hcl.engine.SCALE // 10))
        self.assertEqual([x["operation"] for x in result["braid"]], ["COMP[+]"])
        result = self.call("hcl_calculate", expression="9007199254740993 + 1")
        self.assertTrue(result["decimal"].startswith("9007199254740994."))

    def test_expression_precedence_and_negative_powers(self):
        for expression, expected in (("-2^2", "-4."), ("(-2)^2", "4."),
                                      ("2^3^2", "512."), ("2^-2", "0.25"),
                                      ("1e-3+0.009", "0.010"), ("sqrt(81)", "9.")):
            with self.subTest(expression=expression):
                value = self.call("hcl_calculate", expression=expression)
                self.assertTrue(value["decimal"].startswith(expected), value)

    def test_expression_dispatch_matches_engine(self):
        for expression, value in (("exp(1)", hcl.engine.HCLTranscriber().exp(hcl.engine.SCALE)),
                                  ("ln(2)", hcl.engine.HCLTranscriber().ln(2 * hcl.engine.SCALE)),
                                  ("1/3", hcl.engine.HCLTranscriber().div(hcl.engine.SCALE, 3 * hcl.engine.SCALE))):
            self.assertEqual(self.call("hcl_calculate", expression=expression)["value_integer"], str(value))

    def test_rejects_unsupported_syntax_and_scalar_domains(self):
        for expression in ("__import__('os')", "x.__class__", "[1]", "1/0", "sqrt(-1)",
                           "ln(0)", "2^0.5", "1+", "1,2", "NaN", "1e999999999999999999999"):
            with self.subTest(expression=expression):
                with self.assertRaises((ValueError, ArithmeticError)):
                    self.call("hcl_calculate", expression=expression)

    def test_variables_must_remain_decimal_strings(self):
        with self.assertRaises(ValueError):
            self.call("hcl_calculate", expression="x", variables={"x": 1})
        self.assertTrue(self.call("hcl_calculate", expression="E=m*c^2", variables={"m":"2","c":"3"})["decimal"].startswith("18."))

    def test_unicode_exact_recovery_and_deterministic_reopen(self):
        raw, receipt = self.remember("検索 Möbius \n\x00 <script>untrusted</script>")
        first = self.call("hcl_verify_case", case_path=self.case)
        recovered = self.call("hcl_get_evidence", case_path=self.case, record_id=receipt["record_ids"][0])
        self.assertEqual(recovered["raw_json"], raw)
        self.assertTrue(first["hvp_verified"])
        self.assertEqual(first["memory_line"], receipt["memory_line"])
        request = {"operation":"hcl_verify_case", "input":{"case_path":self.case}}
        process = subprocess.run([sys.executable, "-I", "-B", hcl.__file__], input=json.dumps(request),
                                 text=True, capture_output=True, check=True, timeout=10)
        second = json.loads(process.stdout)
        self.assertTrue(second["ok"])
        self.assertEqual(second["result"]["memory_line"], first["memory_line"])

    def test_duplicate_ingest_is_idempotent_and_sources_are_preserved(self):
        _, first = self.remember()
        _, second = self.remember()
        _, third = self.remember(source="another-observer")
        self.assertEqual((first["added"], second["added"], third["added"]), (1, 0, 1))
        self.assertEqual(second["memory_line"], first["memory_line"])
        self.assertEqual(third["total"], 2)

    def test_recall_is_exact_native_engine_ranking(self):
        for text in ("SQLite search index", "network fetch JSON", "local encrypted database"):
            self.remember(text)
        with hcl.closing(hcl.Case(self.case)) as case:
            mem = case.rehydrate(case.rows())
            expected = mem.recall("SQLite search", 5)
        actual = self.call("hcl_recall_evidence", case_path=self.case, query="SQLite search")
        self.assertEqual([(x["record_id"], int(x["score_integer"])) for x in actual["matches"]], expected)

    def test_confidence_filter_missing_links_and_index_coverage(self):
        self.remember("x " * 3000, evidence_links=["ev:missing"])
        self.remember("inferred", confidence="inferred")
        summary = self.call("hcl_inspect_case", case_path=self.case)
        self.assertEqual(summary["unresolved_evidence_links"], ["ev:missing"])
        self.assertEqual(summary["records_with_partial_index"], 0)
        self.assertEqual(summary["confidence_counts"]["inferred"], 1)
        hits = self.call("hcl_recall_evidence", case_path=self.case, query="inferred", confidence="inferred")
        self.assertTrue(all(x["metadata"]["confidence"] == "inferred" for x in hits["matches"]))

    def test_complete_index_retains_terms_after_old_prefix_cutoff(self):
        _, receipt = self.remember("x" * 6000 + " clipboard_late_feature")
        result = self.call("hcl_recall_evidence", case_path=self.case,
                           query="clipboard_late_feature", limit=100)
        self.assertEqual(result["matches"][0]["record_id"], receipt["record_ids"][0])
        self.assertGreater(result["matches"][0]["metadata"]["indexed_characters"], 6000)
        self.assertFalse(result["matches"][0]["metadata"]["index_truncated"])
        with hcl.closing(hcl.Case(self.case)) as case:
            term = case.rehydrate(case.rows())._terms[0]
            self.assertIn("clipboard_late_feature", term["words"])

    def test_batch_above_old_thirty_two_record_limit(self):
        entries = [{"source": "record-" + str(i), "raw_json": json.dumps({"index": i})}
                   for i in range(33)]
        result = self.call("hcl_remember_evidence", case_path=self.case, entries=entries)
        self.assertEqual(result["added"], 33)

    def test_legacy_case_read_verifies_and_explicit_remember_upgrades_atomically(self):
        raw, receipt = self.remember("x" * 5000 + " old_case_late_feature")
        record_id = receipt["record_ids"][0]
        with sqlite3.connect(Path(self.case) / "evidence.sqlite3") as db:
            row = db.execute("SELECT raw, source FROM records WHERE id=?", (record_id,)).fetchone()
            meta, text = hcl.metadata(bytes(row[0]), row[1], legacy=True)
            old = hcl.memory.HCLMemory()
            old.store(record_id, text)
            db.execute("UPDATE records SET meta=?, index_text=?", (hcl.canonical(meta), text))
            db.execute("UPDATE state SET value=? WHERE key='format'", (hcl.LEGACY_FORMAT,))
            db.execute("UPDATE state SET value=? WHERE key='memory_line'", (old.to_expression(),))
        before = self.call("hcl_verify_case", case_path=self.case)
        self.assertEqual(before["format"], hcl.LEGACY_FORMAT)
        self.assertEqual(before["records_with_partial_index"], 1)
        repeated = self.call("hcl_remember_evidence", case_path=self.case,
                             entries=[{"source": "search", "raw_json": raw}])
        self.assertEqual(repeated["added"], 0)
        after = self.call("hcl_verify_case", case_path=self.case)
        self.assertEqual(after["format"], hcl.FORMAT)
        self.assertEqual(after["records_with_partial_index"], 0)
        self.assertEqual(self.call("hcl_get_evidence", case_path=self.case,
                                   record_id=record_id)["raw_json"], raw)

    def test_byte_tampering_is_rejected(self):
        self.remember()
        with sqlite3.connect(Path(self.case) / "evidence.sqlite3") as db:
            db.execute("UPDATE records SET raw=?", (b'{"changed":true}',))
        with self.assertRaisesRegex(ValueError, "digest mismatch"):
            self.call("hcl_recall_evidence", case_path=self.case, query="search")

    def test_memory_line_tampering_is_rejected(self):
        self.remember()
        with sqlite3.connect(Path(self.case) / "evidence.sqlite3") as db:
            line = db.execute("SELECT value FROM state WHERE key='memory_line'").fetchone()[0]
            fields = line.split(":")
            fields[1] = str(int(fields[1]) + 1)
            db.execute("UPDATE state SET value=? WHERE key='memory_line'", (":".join(fields),))
        with self.assertRaisesRegex(ValueError, "memory line differs"):
            self.call("hcl_verify_case", case_path=self.case)

    def test_stored_hvp_tampering_is_rejected(self):
        _, receipt = self.remember()
        with sqlite3.connect(Path(self.case) / "evidence.sqlite3") as db:
            db.execute("UPDATE records SET hvp='{}'")
        with self.assertRaisesRegex(ValueError, "HVP address mismatch"):
            self.call("hcl_get_evidence", case_path=self.case, record_id=receipt["record_ids"][0])

    def test_invalid_batch_does_not_publish_partial_records(self):
        self.remember()
        with self.assertRaises(ValueError):
            self.call("hcl_remember_evidence", case_path=self.case, entries=[
                {"source":"good","raw_json":'{"good":true}'}, {"source":"bad","raw_json":"not-json"}])
        self.assertEqual(self.call("hcl_inspect_case", case_path=self.case)["records"], 1)

    def test_compare_does_not_pair_ambiguous_observations(self):
        other = str(Path(self.temp.name) / "other")
        self.remember("old-a")
        self.remember("old-b")
        self.remember("new", case=other)
        result = self.call("hcl_compare_cases", left_case=self.case, right_case=other)
        self.assertEqual(result["changes"][0]["status"], "changed")
        self.assertTrue(result["changes"][0]["ambiguous_pairing"])

    def test_concurrent_writers_do_not_lose_evidence(self):
        def store(index):
            request = {"operation":"hcl_remember_evidence", "input":{"case_path":self.case,
                "entries":[{"source":"concurrent", "raw_json":json.dumps({"index":index})}]}}
            process = subprocess.run([sys.executable, "-I", "-B", hcl.__file__], input=json.dumps(request),
                                     text=True, capture_output=True, check=True, timeout=15)
            return json.loads(process.stdout)
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
            results = list(pool.map(store, range(4)))
        self.assertTrue(all(result["ok"] for result in results), results)
        self.assertEqual(self.call("hcl_verify_case", case_path=self.case)["records"], 4)

    def test_reading_missing_case_does_not_create_it(self):
        with self.assertRaises(ValueError):
            self.call("hcl_inspect_case", case_path=self.case)
        self.assertFalse(Path(self.case).exists())


if __name__ == "__main__":
    unittest.main()
