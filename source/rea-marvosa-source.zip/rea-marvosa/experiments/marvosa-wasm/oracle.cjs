// Independent native-WebAssembly oracle, used only by qualification.
const fs = require("node:fs");
const vm = require("node:vm");
const path = require("node:path");
const root = process.argv[2];
const driver = { exports: {} };
const boundary = {
  instantiate: (module, imports) => new WebAssembly.Instance(module, imports),
  write: (memory, offset, bytes) =>
    new Uint8Array(memory.buffer, offset, bytes.length).set(bytes),
  read: (memory, offset, count) =>
    Array.from(new Uint8Array(memory.buffer, offset, count)),
};
const context = vm.createContext({
  exports: driver.exports,
  require: (name) => {
    if (name === "hcl:wasm") return boundary;
    if (name === "./mappings.wasm")
      return new WebAssembly.Module(
        fs.readFileSync(path.join(root, "mappings.wasm")),
      );
    throw new Error("Unexpected driver dependency: " + name);
  },
});
vm.runInContext(
  fs.readFileSync(path.join(root, "driver.cjs"), "utf8"),
  context,
);
const calls = JSON.parse(fs.readFileSync(process.argv[3], "utf8"));
process.stdout.write(
  JSON.stringify(
    calls.map((call) =>
      driver.exports[call.entry](...JSON.parse(call.arguments_json)),
    ),
  ),
);
