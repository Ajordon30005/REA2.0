// Test-only ABI driver. The Rust-compiled mappings.wasm is used unchanged.
const boundary = require("hcl:wasm");
const binary = require("./mappings.wasm");
let captured = [];
const instance = boundary.instantiate(binary, {
  env: {
    mapping_callback(a, b, c, d, e, f, g, h, i, j) {
      captured.push([a, b, c, d, e, f, g, h, i, j]);
    },
  },
});
const wasm = instance.exports;

exports.inspect = function (text, queryIndices) {
  const bytes = [];
  for (let i = 0; i < text.length; i++) bytes.push(text.charCodeAt(i));
  const buffer = wasm.allocate_mappings(bytes.length) >>> 0;
  boundary.write(wasm.memory, buffer, bytes);
  const written = boundary.read(wasm.memory, buffer, bytes.length);
  const mappings = wasm.parse_mappings(buffer);
  if (!mappings) return { error: wasm.get_last_error(), written };
  captured = [];
  wasm.by_generated_location(mappings);
  const generated = captured;
  captured = [];
  wasm.compute_column_spans(mappings);
  wasm.by_generated_location(mappings);
  const spans = captured;
  captured = [];
  wasm.by_original_location(mappings);
  const original = captured;
  const queries = [];
  for (let i = 0; i < generated.length; i++) {
    if (queryIndices && queryIndices.indexOf(i) < 0) continue;
    // Selected real mappings are queried in both directions, at both biases.
    const m = generated[i];
    captured = [];
    wasm.original_location_for(mappings, m[0], m[1], 1);
    const lower = captured;
    captured = [];
    wasm.original_location_for(mappings, m[0], m[1], 2);
    const upper = captured;
    captured = [];
    if (m[4]) wasm.generated_location_for(mappings, m[5], m[6], m[7], 1);
    const back = captured;
    captured = [];
    if (m[4]) wasm.all_generated_locations_for(mappings, m[5], m[6], 1, m[7]);
    queries.push({ lower, upper, back, all: captured });
  }
  wasm.free_mappings(mappings);
  return { generated, spans, original, queries, written };
};
