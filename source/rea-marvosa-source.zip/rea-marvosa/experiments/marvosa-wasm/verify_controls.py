#!/usr/bin/env python3
"""Generated format/word controls versus native WASM, separate from OSS proof."""
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location("objects", ROOT / "experiments/marvosa-objects/verify.py")
objects = importlib.util.module_from_spec(spec)
spec.loader.exec_module(objects)


def u(value):
    out = bytearray()
    while True:
        byte = value & 127
        value >>= 7
        out.append(byte | (128 if value else 0))
        if not value:
            return bytes(out)


def vector(items):
    return u(len(items)) + b"".join(items)


def section(index, content):
    return bytes([index]) + u(len(content)) + content


def build():
    types, functions, calls = [], [], []
    def add(name, params, results, code):
        signature = (params, results)
        if signature not in types:
            types.append(signature)
        functions.append((name, types.index(signature), code))
        return len(functions) - 1
    def case(name, *args):
        calls.append({"entry": name, "arguments_json": json.dumps(args)})
    for width, type_, base in ((32, b"\x7f", 0x67), (64, b"\x7e", 0x79)):
        unary = ["clz", "ctz", "popcnt"]
        binary = ["add", "sub", "mul", "div_s", "div_u", "rem_s", "rem_u", "and", "or", "xor", "shl", "shr_s", "shr_u", "rotl", "rotr"]
        for i, op in enumerate(unary + binary):
            name = f"i{width}_{op}"
            arity = 1 if op in unary else 2
            add(name, type_ * arity, type_, b"\x20\0" + (b"\x20\1" if arity == 2 else b"") + bytes([base + i]))
            if arity == 1:
                for x in (0, 1, -1, 1 << (width - 1)):
                    case(name, x)
            else:
                for args in ((-7, 3), (-(1 << (width - 1)), -1), ((1 << width) - 1, width + 1), (0, 0)):
                    case(name, *args)
        compare_base = 0x45 if width == 32 else 0x50
        for i, op in enumerate(["eqz", "eq", "ne", "lt_s", "lt_u", "gt_s", "gt_u", "le_s", "le_u", "ge_s", "ge_u"]):
            name = f"i{width}_{op}"
            arity = 1 if op == "eqz" else 2
            add(name, type_ * arity, b"\x7f", b"\x20\0" + (b"\x20\1" if arity == 2 else b"") + bytes([compare_base + i]))
            case(name, *([-1] if arity == 1 else [-1, 1]))
    for name, input_, output, opcode, values in (
        ("wrap64", b"\x7e", b"\x7f", 0xa7, [2**63 - 1, -2**63, 2**32 + 7]),
        ("extend32", b"\x7f", b"\x7e", 0xac, [-1, -2**31, 2**31 - 1]),
        ("extend32u", b"\x7f", b"\x7e", 0xad, [-1, -2**31]),
        ("extend8", b"\x7f", b"\x7f", 0xc0, [128, 255, 256]),
        ("extend16", b"\x7e", b"\x7e", 0xc3, [32768, 65535, 65536]),
    ):
        add(name, input_, output, b"\x20\0" + bytes([opcode]))
        for value in values:
            case(name, value)
    # Parameter-carrying loop, branch-to-function, and branch table values.
    loop_type = types.index((b"\x7f", b"\x7f"))
    add("loop_params", b"\x7f", b"\x7f", b"\x20\0\x03" + u(loop_type) +
        b"\x21\0\x20\0\x45\x04\x40\x41\x2a\x0f\x0b\x20\0\x41\1\x6b\x0c\0\x0b")
    for value in (0, 5, 50):
        case("loop_params", value)
    add("branch_table", b"\x7f", b"\x7f", b"\x02\x7f\x41\7\x20\0\x0e\2\0\1\0\x0b")
    for value in (0, 1, 2, -1):
        case("branch_table", value)
    add_index = next(i for i, f in enumerate(functions) if f[0] == "i32_add")
    constant_index = add("constant", b"", b"\x7f", b"\x41\1")
    add("indirect", b"\x7f\x7f\x7f", b"\x7f", b"\x20\0\x20\1\x20\2\x11" + u(functions[add_index][1]) + b"\0")
    for index in (0, 1, 2, 3, -1):
        case("indirect", 10, 20, index)
    add("memory", b"\x7f\x7f", b"\x7f", b"\x20\0\x20\1\x36\0\1\x20\0\x2c\0\1")
    for offset, value in ((0, 255), (4, 128), (65531, 127), (65532, 1), (-1, 5)):
        case("memory", offset, value)
    add("copy", b"", b"\x7f", b"\x41\1\x41\0\x41\3\xfc\x0a\0\0\x41\0\x28\0\0")
    case("copy")
    add("fill", b"", b"\x7f", b"\x41\2\x41\x7f\x41\2\xfc\x0b\0\x41\0\x28\0\0")
    case("fill")
    add("grow", b"\x7f", b"\x7f", b"\x20\0\x40\0")
    for delta in (1, 1, 0, -1):
        case("grow", delta)
    add("global", b"\x7f", b"\x7f", b"\x23\0\x20\0\x6a\x24\0\x23\0")
    case("global", 5)
    case("global", -20)
    add("float", b"\x7c", b"\x7c", b"\x20\0\x20\0\xa0")
    signature = lambda p, r: b"\x60" + u(len(p)) + p + u(len(r)) + r
    exports = [u(len(n.encode())) + n.encode() + b"\0" + u(i) for i, (n, _, _) in enumerate(functions)]
    bodies = [b"\0" + code + b"\x0b" for _, _, code in functions]
    data = b"\0asm\1\0\0\0"
    data += section(1, vector([signature(*t) for t in types]))
    data += section(3, vector([u(t) for _, t, _ in functions]))
    data += section(4, b"\1\x70\0\3")
    data += section(5, b"\1\1\1\2")
    data += section(6, b"\1\x7f\1\x41\7\x0b")
    data += section(7, vector(exports))
    data += section(9, b"\1\0\x41\0\x0b" + vector([u(add_index), u(constant_index)]))
    data += section(10, vector([u(len(body)) + body for body in bodies]))
    data += section(11, b"\1\0\x41\0\x0b\4abcd")
    metadata = {name: list(types[type_][0]) for name, type_, _ in functions}
    return data, calls, metadata


def main():
    out = Path(sys.argv[1]).resolve()
    out.mkdir(parents=True, exist_ok=False)
    data, calls, metadata = build()
    (out / "controls.wasm").write_bytes(data)
    (out / "calls.json").write_text(json.dumps(calls))
    (out / "types.json").write_text(json.dumps(metadata))
    oracle = r'''
const fs=require('fs'),root=process.argv[1],types=JSON.parse(fs.readFileSync(root+'/types.json'));
const instance=new WebAssembly.Instance(new WebAssembly.Module(fs.readFileSync(root+'/controls.wasm')));
const calls=JSON.parse(fs.readFileSync(root+'/calls.json'));
process.stdout.write(JSON.stringify(calls.map(c=>{try {
  const tokens=JSON.parse(c.arguments_json.replace(/(-?[0-9]+)/g,'"$1"'));
  const args=tokens.map((v,i)=>types[c.entry][i]===126?BigInt(v):Number(v));
  const value=instance.exports[c.entry](...args);return {value:String(value)};
}catch(e){return {error:e instanceof WebAssembly.RuntimeError};}})));
'''
    (out / "oracle.cjs").write_text(oracle)
    expected = json.loads(subprocess.check_output(["node", "-e", oracle, str(out)]))
    (out / "original.json").write_text(json.dumps(expected))
    observed, raw, metrics = objects.qualification.cli(out, "controls", "hcl-transcribe", str(out / "controls.wasm"),
        "--calls", json.dumps(calls + [{"entry": "float", "arguments_json": "[2]"}]))
    report = observed["normalized_result"]
    for actual, wanted in zip(report["execution"]["calls"], expected):
        if wanted.get("error"):
            assert actual["status"] == "error" and actual["error"]["code"] == "WasmTrap", actual
        else:
            assert actual["status"] == "completed", actual
            assert objects.decode(actual["value"]) == int(wanted["value"]), (actual, wanted)
    assert report["execution"]["calls"][-1]["status"] == "unsupported"
    sys.path.insert(0, str(ROOT / "bridge/marvosa"))
    from transcription.trace import unpack
    assert sum(1 for _ in unpack(report["execution"]["braid"])) == report["execution"]["generator_count"]
    assert all(item["start"] <= item["end"] <= report["execution"]["generator_count"] for item in unpack(report["execution"]["braid_sources"]))
    objects.qualification.archive(raw)
    summary = {"native_wasm_comparisons": len(expected), "matched": len(expected),
               "trap_cases": sum(item.get("error", False) for item in expected),
               "explicit_float_unknown": True, "complete_trace_verified": True, "metrics": metrics}
    (out / "summary.json").write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary), flush=True)


if __name__ == "__main__":
    main()
