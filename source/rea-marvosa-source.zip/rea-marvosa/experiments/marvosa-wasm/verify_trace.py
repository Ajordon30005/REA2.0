#!/usr/bin/env python3
"""Compare every current native generator with the captured expanded real run."""
import base64
import gzip
import importlib.util
import json
from pathlib import Path
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location("objects", ROOT / "experiments/marvosa-objects/verify.py")
objects = importlib.util.module_from_spec(spec)
spec.loader.exec_module(objects)
sys.path.insert(0, str(ROOT / "bridge/marvosa"))
from transcription.trace import unpack


def main():
    baseline, out = Path(sys.argv[1]), Path(sys.argv[2])
    out.mkdir(parents=True, exist_ok=False)
    with gzip.open(baseline / "expanded.json.gz", "rb") as stream:
        raw = stream.read()
    old = json.loads(raw)["normalized_result"]
    calls = json.loads((baseline / "calls.json").read_text())
    with tempfile.TemporaryDirectory(prefix="hcl-trace-source-") as directory:
        source = Path(directory)
        for item in old["program"]["sources"]:
            path = source / item["path"]
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(base64.b64decode(item["content"], validate=True) if item["encoding"] == "base64" else item["content"].encode())
        evidence, capture, metrics = objects.qualification.cli(out, "packed", "hcl-transcribe", str(source), "--calls", json.dumps(calls))
    new = evidence["normalized_result"]
    assert old["execution"]["calls"] == new["execution"]["calls"]
    for field in ("braid", "braid_sources"):
        assert old["execution"][field] == list(unpack(new["execution"][field])), field
    summary = {"all_generators_identical": len(old["execution"]["braid"]),
               "all_source_ranges_identical": len(old["execution"]["braid_sources"]), "values_identical": True,
               "expanded_response_bytes": len(raw), "packed_response_bytes": metrics["output_bytes"],
               "metrics": metrics, "timing_note": "Concurrent verification work; compare decoded content and bytes, not execution speed."}
    (out / "summary.json").write_text(json.dumps(summary, indent=2))
    objects.qualification.archive(capture)
    print(json.dumps(summary), flush=True)


if __name__ == "__main__":
    main()
