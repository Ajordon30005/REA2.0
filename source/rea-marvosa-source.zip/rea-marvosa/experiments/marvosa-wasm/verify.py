#!/usr/bin/env python3
"""Unchanged Mozilla source-map WASM through public CLI versus native Node WASM."""
import argparse
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location("objects", ROOT / "experiments/marvosa-objects/verify.py")
objects = importlib.util.module_from_spec(spec)
spec.loader.exec_module(objects)
qualification = objects.qualification


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    owner = tempfile.TemporaryDirectory(prefix="rea-hcl-wasm-source-")
    project = Path(owner.name) / "inputs"
    project.mkdir()
    binary = ROOT / "node_modules/source-map/lib/mappings.wasm"
    shutil.copy2(binary, project / "mappings.wasm")
    shutil.copy2(Path(__file__).with_name("driver.cjs"), project / "driver.cjs")
    shutil.copy2(ROOT / "node_modules/source-map/LICENSE", out / "source-map.LICENSE")
    shutil.copy2(ROOT / "node_modules/source-map/package.json", out / "source-map.package.json")
    for package in ("resolve-uri", "trace-mapping"):
        shutil.copy2(ROOT / "node_modules/@jridgewell" / package / "LICENSE", out / (package + ".LICENSE"))
    map_paths = [ROOT / "node_modules/@jridgewell/resolve-uri/dist/resolve-uri.umd.js.map",
                 ROOT / "node_modules/@jridgewell/trace-mapping/types/strip-filename.d.cts.map"]
    calls, maps = [], []
    for index, path in enumerate(map_paths):
        shutil.copy2(path, project / path.name)
        mappings = json.loads(path.read_text())["mappings"]
        count = sum(len(line.split(",")) for line in mappings.split(";") if line)
        queries = [0, 1, 20, 200, 500, count - 1] if index == 0 else list(range(count))
        calls.append({"module": "driver.cjs", "entry": "inspect", "arguments_json": json.dumps([mappings, queries])})
        maps.append({"path": str(path.relative_to(ROOT)), "sha256": qualification.sha(path),
                     "bytes": path.stat().st_size, "mapping_entries": count, "query_entries": len(queries)})
    for malformed in ("!", "g", "D", "gggggggI", ""):
        calls.append({"module": "driver.cjs", "entry": "inspect", "arguments_json": json.dumps([malformed])})
    (out / "calls.json").write_text(json.dumps(calls))
    shutil.copytree(project, out / "inputs")
    oracle = Path(__file__).with_name("oracle.cjs")
    expected = json.loads(subprocess.check_output(["node", str(oracle), str(project), str(out / "calls.json")]))
    (out / "original.json").write_text(json.dumps(expected))
    shutil.copy2(oracle, out / "oracle.cjs")
    source_files = [*sorted((ROOT / "bridge/marvosa/transcription").glob("*.py")), ROOT / "bridge/marvosa/rea_hcl.py",
                    ROOT / "src/marvosa/MarvosaSourceInput.ts", ROOT / "src/domain/hclTranscription.ts",
                    ROOT / "src/domain/marvosa.ts", ROOT / "src/generatedPackageMetadata.ts"]
    manifest = {"package": "source-map", "version": json.loads((out / "source-map.package.json").read_text())["version"],
                "unchanged_binary_sha256": qualification.sha(binary), "binary_bytes": binary.stat().st_size,
                "files_sha256": {str(p.relative_to(project)): qualification.sha(p) for p in project.rglob("*") if p.is_file()},
                "whole_real_maps": maps, "implementation_sha256": {str(p.relative_to(ROOT)): qualification.sha(p) for p in source_files},
                "oracle": "Independent Node WebAssembly.Instance of the same unchanged binary; identical ABI-only driver",
                "external_model_calls": 0, "model_tokens": "Not applicable; no external model",
                "simultaneous_process_family_peak_memory": "not measured"}
    (out / "input-manifest.json").write_text(json.dumps(manifest, indent=2))
    for path in source_files:
        target = out / "executed-source" / path.relative_to(ROOT)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, target)
    result, raw, metrics = qualification.cli(out, "wasm", "hcl-transcribe", str(project), "--calls", json.dumps(calls))
    report = result["normalized_result"]
    objects.compare(report, expected)
    assert report["working_memory"]["source_regeneration_verified"]
    target_unknowns = [item for item in report["analysis"]["unknowns"] if item["id"].startswith(("mappings.wasm:", "driver.cjs:"))]
    assert not target_unknowns, target_unknowns
    sys.path.insert(0, str(ROOT / "bridge/marvosa"))
    from transcription.trace import unpack
    def verify_trace(execution):
        count = sum(1 for _ in unpack(execution["braid"]))
        assert count == execution["generator_count"]
        assert all(0 <= row["start"] <= row["end"] <= count for row in unpack(execution["braid_sources"]))
        return {"generators": count, "expanded_generator_bytes": execution["braid"]["uncompressed_bytes"],
                "encoded_generator_bytes": len(execution["braid"]["base64"]),
                "expanded_source_range_bytes": execution["braid_sources"]["uncompressed_bytes"],
                "encoded_source_range_bytes": len(execution["braid_sources"]["base64"])}
    trace = verify_trace(report["execution"])
    graph = out / "wasm.hcl.json"
    graph.write_text(json.dumps(report["program"], separators=(",", ":")))
    summary = {"native_wasm_calls_matched": len(expected), "whole_real_maps": maps,
               "decoded_binary_functions": sum(f["path"] == "mappings.wasm" for f in report["analysis"]["functions"]),
               "coverage": report["coverage"], "target_unknown_syntax": 0,
               "executed_nodes": len(report["execution"]["executed_nodes"]),
               "trace": trace, "metrics": metrics}
    (out / "summary.json").write_text(json.dumps(summary, indent=2))
    qualification.archive(raw)
    hidden = project.with_name("source-unavailable")
    project.rename(hidden)
    try:
        assert not project.exists()
        replay, replay_raw, replay_metrics = qualification.cli(out, "saved", "hcl-run", str(graph), "--calls", json.dumps([calls[0]]))
        assert not project.exists()
    finally:
        hidden.rename(project)
    objects.compare(replay["normalized_result"], expected[:1])
    replay_trace = verify_trace(replay["normalized_result"]["execution"])
    qualification.archive(replay_raw)
    summary.update(saved_graph_without_sources="passed", saved_trace=replay_trace, saved_metrics=replay_metrics)
    (out / "summary.json").write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary), flush=True)


if __name__ == "__main__":
    main()
