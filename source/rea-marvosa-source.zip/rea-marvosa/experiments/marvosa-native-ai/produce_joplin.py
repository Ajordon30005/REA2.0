"""Exercise unmodified Joplin CLI on a fresh, local-only test profile."""
import argparse
import hashlib
import json
from pathlib import Path
import sqlite3
import subprocess
import tarfile
import time


def run(work, node):
    install = work / "joplin/node_modules"
    cli = install / "joplin/main.js"
    output = work / "joplin-case"
    output.mkdir(parents=True, exist_ok=False)
    profile = output / "profile"
    transcript = []
    records = []

    def command(*args):
        started = time.perf_counter()
        result = subprocess.run([node, str(cli), "--profile", str(profile), *args],
                                capture_output=True, text=True, check=False)
        transcript.append({"arguments": list(args), "returncode": result.returncode,
                           "stdout": result.stdout, "stderr": result.stderr,
                           "elapsed_ms": (time.perf_counter()-started)*1000})
        if result.returncode:
            raise RuntimeError(repr(args) + ": " + result.stderr + result.stdout)
        return result.stdout

    def rows(sql, args=()):
        with sqlite3.connect((profile / "database.sqlite").as_uri()+"?mode=ro", uri=True) as db:
            db.row_factory = sqlite3.Row
            return [dict(row) for row in db.execute(sql, args)]

    def record(key, description, observed):
        records.append({"key": key, "operation": "probe_joplin_"+key,
                        "confidence": "observed", "description": description,
                        "observed": observed})

    try:
        command("config", "sync.target", "0")
        command("config", "sync.interval", "0")
        version = command("version").strip()
        command("mkbook", "HCL Research")
        command("use", "HCL Research")
        command("mknote", "Star chart")
        body = "# Calibration\n\nbody_only_quasar\n\nUnicode: Möbius 検索 🧠\n"
        command("set", "Star chart", "body", body)
        display = command("cat", "Star chart")
        note = rows("SELECT id,title,body,parent_id FROM notes WHERE title=?", ("Star chart",))[0]
        assert note["body"] == body and "Möbius 検索 🧠" in display
        record("storage", "Joplin saves the note body in the notes table of profile/database.sqlite and cat displays the Unicode content.",
               {"database_file": "database.sqlite", "table": "notes", "note_id": note["id"],
                "title": note["title"], "body": note["body"], "display": display})
        hidden = json.loads(command("ls", "body_only_quasar", "--format", "json"))
        visible = json.loads(command("ls", "Star chart", "--format", "json"))
        assert hidden == [] and len(visible) == 1
        record("title_filter", "CLI ls filters note titles: a body-only token returns no notes, while the exact note title returns one.",
               {"body_query": "body_only_quasar", "body_query_count": len(hidden),
                "title_query": "Star chart", "title_query_count": len(visible)})
        command("tag", "add", "astronomy", note["id"])
        tags = command("tag", "notetags", note["id"])
        relations = rows("SELECT tags.title, note_tags.note_id FROM tags JOIN note_tags ON tags.id=note_tags.tag_id WHERE note_tags.note_id=?", (note["id"],))
        assert "astronomy" in tags and len(relations) == 1
        record("tags", "Adding astronomy creates a tags entry and a note_tags relationship; tag notetags reports astronomy.",
               {"tag_output": tags, "relations": relations})
        command("ren", note["id"], "Calibration record")
        renamed = rows("SELECT id,title,body FROM notes WHERE id=?", (note["id"],))[0]
        assert renamed["title"] == "Calibration record" and renamed["body"] == body
        record("rename", "Renaming changes the note title and preserves its ID and body.",
               {"before_title": "Star chart", "after_title": renamed["title"],
                "id_preserved": renamed["id"] == note["id"], "body_preserved": renamed["body"] == body})
        command("mktodo", "Audit export")
        command("done", "Audit export")
        todo = rows("SELECT title,is_todo,todo_completed FROM notes WHERE title=?", ("Audit export",))[0]
        assert todo["is_todo"] == 1 and todo["todo_completed"] > 0
        record("todo", "Completing Audit export retains is_todo=1 and sets a nonzero todo_completed timestamp.", todo)
        markdown = output / "markdown-export"
        command("export", str(markdown), "--format", "md", "--notebook", "HCL Research")
        exported = [{"path": str(file.relative_to(markdown)), "text": file.read_text()}
                    for file in sorted(markdown.rglob("*.md"))]
        assert any("body_only_quasar" in item["text"] and "Möbius 検索 🧠" in item["text"] for item in exported)
        record("markdown", "Markdown export preserves the note body and Unicode in an actual .md file.",
               {"format": "md", "files": exported})
        archive = output / "research.jex"
        command("export", str(archive), "--format", "jex", "--notebook", "HCL Research")
        with tarfile.open(archive) as package:
            members = package.getnames()
            note_files = [package.extractfile(item).read().decode() for item in package.getmembers()
                          if item.isfile() and item.name.endswith(".md")]
        assert any("body_only_quasar" in text for text in note_files)
        record("jex", "The JEX export is a readable tar archive containing note Markdown and Joplin metadata.",
               {"format": "jex", "container": "tar", "members": members,
                "contains_original_body": True, "sha256": hashlib.sha256(archive.read_bytes()).hexdigest()})
        command("mkbook", "Archive")
        command("cp", note["id"], "Archive")
        copies = rows("SELECT notes.id,notes.body,folders.title AS notebook FROM notes JOIN folders ON notes.parent_id=folders.id WHERE notes.title=?", ("Calibration record",))
        assert len(copies) == 2 and len({item["id"] for item in copies}) == 2
        assert all(item["body"] == body for item in copies)
        record("copy", "Copying a note to Archive creates a different note ID while preserving its body.",
               {"notes": copies})
        command("rmnote", note["id"], "--force")
        trashed = rows("SELECT id,deleted_time FROM notes WHERE id=?", (note["id"],))[0]
        assert trashed["deleted_time"] > 0
        command("restore", note["id"])
        restored = rows("SELECT id,deleted_time,body FROM notes WHERE id=?", (note["id"],))[0]
        assert restored["deleted_time"] == 0 and restored["body"] == body
        record("trash_restore", "Default deletion uses the trash: deleted_time becomes nonzero; restore resets it to zero and keeps the body.",
               {"deleted_time_in_trash": trashed["deleted_time"],
                "deleted_time_after_restore": restored["deleted_time"], "body_preserved": True})
        metadata = json.loads((install / "joplin/package.json").read_text())
        lib_metadata = json.loads((install / "@joplin/lib/package.json").read_text())
        result = {"target": "Joplin CLI", "version": metadata["version"],
                  "library_version": lib_metadata["version"], "license": metadata["license"],
                  "version_output": version, "records": records, "checks_passed": len(records),
                  "real_application": True, "remote_sync": False,
                  "elapsed_ms": sum(item["elapsed_ms"] for item in transcript)}
        (output / "observations.json").write_text(json.dumps(result, ensure_ascii=False, indent=2)+"\n")
        print(json.dumps({"target": "Joplin CLI", "version": metadata["version"], "checks": len(records)}))
    finally:
        (output / "commands.json").write_text(json.dumps(transcript, ensure_ascii=False, indent=2)+"\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("work", type=Path)
    parser.add_argument("--node", default="node")
    args = parser.parse_args()
    run(args.work.resolve(), args.node)
