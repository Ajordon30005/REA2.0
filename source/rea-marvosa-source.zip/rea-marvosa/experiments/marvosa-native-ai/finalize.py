"""Publish captured results with precision-safe native integer metadata."""
import argparse
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "bridge/marvosa"))
from native_ai import wire_value


def run(work, output):
    output.mkdir(parents=True, exist_ok=True)
    unchanged = {
        "native-ai-cases.json": "cases.json",
        "application-probe-evidence.json": "application-probe-evidence.json",
        "joplin-case/observations.json": "joplin-observations.json",
        "joplin-case/commands.json": "joplin-commands.json",
        "joplin-rea-summary.json": "joplin-rea-summary.json",
        "joplin-source-manifest.json": "joplin-source-manifest.json",
        "joplin/package-lock.json": "joplin-install-lock.json",
        "joplin/package.json": "joplin-install-package.json",
        "sqlite/observations.json": "sqlite-observations.json",
        "artifact-roundtrips.json": "artifact-roundtrips.json",
        "rea-calls.json": "rea-calls.json",
    }
    for source, destination in unchanged.items():
        (output / destination).write_bytes((work / source).read_bytes())
    comparison = json.loads((work / "comparison/comparison.json").read_text())
    (output / "comparison.json").write_text(json.dumps(wire_value(comparison), ensure_ascii=False, indent=2)+"\n")
    completion = json.loads((work / "completion-probe.json").read_text())
    for case in completion["results"]:
        normalized = 0
        for probe in case["probes"]:
            words = probe["generated_continuation"].split()
            if words and words[0].rstrip('\",}') == probe["expected_next_word"]:
                normalized += 1
        case["json_delimiter_normalized_correct"] = normalized
    completion["additional_scoring_note"] = (
        "Strict original scores are retained. After observing JSON delimiters in the generated tokens, "
        "an additional diagnostic strips only trailing JSON quote/comma/brace characters from the first word. "
        "This post-hoc diagnostic is not the frozen held-out QA score or proof of semantic generalization.")
    (output / "completion-probe.json").write_text(json.dumps(wire_value(completion), ensure_ascii=False, indent=2)+"\n")
    print(json.dumps({"output": str(output), "cases": len(comparison["results"]),
                      "completion_normalized": [{"project": case["project"], "correct": case["json_delimiter_normalized_correct"], "total": len(case["probes"])} for case in completion["results"]]}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("work", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    run(args.work.resolve(), args.output.resolve())
