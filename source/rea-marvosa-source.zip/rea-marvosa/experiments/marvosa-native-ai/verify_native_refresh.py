"""Compare the integrated adapter against the captured pre-integration source."""
import copy
import hashlib
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "bridge/marvosa"))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from native_ai import ResidentHCLAI, wire_value
from native_refresh import NativeRefreshBatch


def state(ai):
    vm = ai.model.memory.vm
    value = {"depth": ai.model.w, "terms": vm._terms,
             "braid_log": vm._braid_log, "access_log": sorted(vm._access_log),
             "composite": [vm._composite.phase_frac, vm._composite.amp],
             "signature": vm._sig, "hvp": ai.model.memory.hvp,
             "sigs": ai.model.memory.sigs, "accessed": sorted(ai.model.memory.accessed),
             "evidence": ai._evidence}
    return hashlib.sha256(json.dumps(wire_value(value), sort_keys=True, default=sorted).encode()).hexdigest()


def run(output):
    # Load the exact earlier adapter against the same original engine sources.
    # No native methods or model outputs are replaced in the reference model.
    source = Path(__file__).parent / "results/integration/before-native-ai.py.txt"
    namespace = {"__file__": str(ROOT / "bridge/marvosa/native_ai.py"),
                 "__name__": "native_ai_before_integration"}
    exec(compile(source.read_text(), str(source), "exec"), namespace)
    original, scheduled = namespace["ResidentHCLAI"](), ResidentHCLAI()
    steps = [("experience", "a", "A note keeps its identifier and original body."),
             ("experience", "b", "A rename changes its title and keeps its identifier."),
             ("interact", "A note keeps"),
             ("experience", "a", "A note keeps its identifier and original body."),
             ("interact", "A rename changes"),
             ("interact", "A rename changes its title and keeps its identifier."),
             ("experience", "b", "A rename changes its title and keeps its identifier."),
             ("experience", "a", "A note keeps its identifier and original body."),
             ("interact", "A note keeps its identifier"),
             ("feedback", ["a"]),
             ("interact", "A rename changes its title"),
             ("get", "a"), ("get", "b")]
    measurements = []
    for step in steps:
        operation, *args = step
        def execute(ai):
            # Exercise the integrated ask boundary, including native recall.
            return getattr(ai, "ask" if operation == "interact" else operation)(*args)
        started = time.perf_counter()
        expected = execute(original)
        original_ms = (time.perf_counter() - started) * 1000
        started = time.perf_counter()
        observed = execute(scheduled)
        scheduled_ms = (time.perf_counter() - started) * 1000
        assert expected == observed, (step, "response mismatch")
        expected_state, observed_state = state(original), state(scheduled)
        assert expected_state == observed_state, (step, "native state mismatch")
        assert "_recompose" not in scheduled.model.memory.__dict__
        assert "_update_signature" not in scheduled.model.memory.vm.__dict__
        measurements.append({"step": step, "response_identical": True,
                             "native_state_sha256": observed_state,
                             "original_ms": original_ms, "scheduled_ms": scheduled_ms})
    # Both a conflict before learning and an exception after mutation must
    # restore original methods and leave the native summary consistent.
    for mutate_first in (False, True):
        expected_copy, observed_copy = copy.deepcopy(original), copy.deepcopy(scheduled)
        for ai, use_batch in ((expected_copy, False), (observed_copy, True)):
            try:
                if use_batch:
                    with NativeRefreshBatch(ai.model.memory):
                        if mutate_first:
                            ai.model.train("Fresh experience changes a trace and its amplitude.")
                        raise RuntimeError("controlled interrupted learning turn")
                if mutate_first:
                    ai.model.train("Fresh experience changes a trace and its amplitude.")
                raise RuntimeError("controlled interrupted learning turn")
            except RuntimeError as error:
                assert str(error) == "controlled interrupted learning turn"
        assert state(expected_copy) == state(observed_copy)
        assert "_recompose" not in observed_copy.model.memory.__dict__
        assert "_update_signature" not in observed_copy.model.memory.vm.__dict__
    result = {"kind": "native-refresh-production-equivalence-v2",
              "steps": measurements, "identical_native_states": len(measurements),
              "exception_restoration_checks": 2, "final_runtime": scheduled.status(),
              "scope": "Integrated experience/ask/feedback/get compared against captured original adapter with the same unchanged native sources. All native trace, HVP, signature and operation-log states compared. Exception checks separately verify scheduler restoration. Performance qualification uses the real-case CLI verifier."}
    output.write_text(json.dumps(wire_value(result), ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"identical_native_states": len(measurements), "exception_restoration_checks": 2,
                      "original_ms": sum(row["original_ms"] for row in measurements),
                      "scheduled_ms": sum(row["scheduled_ms"] for row in measurements)}))


if __name__ == "__main__":
    run(Path(sys.argv[1]).resolve())
