"""Exercise the actual resident CLI before and after refresh integration.

Both sides are independent Python processes using real native engines. The
baseline is the captured .4 application source, with the same pinned vendor
files. Requests use complete observations from real application work.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parents[2]
SNAPSHOTS = Path(__file__).parent / "results/integration"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def requests_for(case):
    requests = []

    def add(phase, operation, **arguments):
        requests.append({"phase": phase, "request": {"operation": operation, **arguments}})

    for record in case["records"]:
        add("initial_learning", "experience", evidence_id=record["evidence_id"], text=record["text"])
    add("initial_status", "status")
    for _ in range(2):
        for record in case["records"]:
            add("repeated_learning", "experience", evidence_id=record["evidence_id"], text=record["text"])
    add("repeated_status", "status")
    for _ in range(2):
        for record in case["records"]:
            add("readable_interaction", "ask", prompt=record["record"]["normalized_result"]["description"])
    for record in case["records"]:
        words = record["record"]["normalized_result"]["description"].split()
        add("source_completion", "ask", prompt=" ".join(words[:len(words) // 2]))
    for record in case["records"]:
        add("exact_recovery", "get", evidence_id=record["evidence_id"])
    first = case["records"][0]
    add("conflicting_identity", "experience", evidence_id=first["evidence_id"], text=first["text"] + "changed")
    add("feedback", "feedback", evidence_ids=[first["evidence_id"]])
    for record in case["records"]:
        add("recovery_after_feedback", "get", evidence_id=record["evidence_id"])
    add("final_status", "status")
    return requests


def session(root, requests, case, output):
    records = {record["evidence_id"]: record["text"] for record in case["records"]}
    started = time.perf_counter()
    rows = []
    with tempfile.TemporaryFile(mode="w+") as errors:
        process = subprocess.Popen([sys.executable, "-I", "-B", str(root / "scripts/hcl-ai.py")],
                                   stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=errors,
                                   text=True, encoding="utf-8", bufsize=1)
        try:
            for index, entry in enumerate(requests):
                request = entry["request"]
                sent = time.perf_counter()
                process.stdin.write(json.dumps(request, ensure_ascii=False) + "\n")
                process.stdin.flush()
                line = process.stdout.readline()
                if not line:
                    errors.seek(0)
                    raise RuntimeError("CLI stopped: " + errors.read())
                response = json.loads(line)
                elapsed = (time.perf_counter() - sent) * 1000
                phase = entry["phase"]
                if phase == "conflicting_identity":
                    assert not response["ok"] and response["error"]["code"] == "ValueError"
                else:
                    assert response["ok"], response
                    result = response["result"]
                    if request["operation"] == "get":
                        assert result["text"] == records[request["evidence_id"]]
                    elif request["operation"] == "ask":
                        assert result["bit_perfect"] and result["integrity"]["intact"]
                    elif request["operation"] == "status":
                        assert result["evidence_records"] == len(records)
                        assert not result["mst"] and result["integrity"]["intact"]
                    elif request["operation"] == "experience":
                        assert result["new_evidence"] == (phase == "initial_learning")
                    elif request["operation"] == "feedback":
                        assert result["reinforced_in_place"]
                rows.append({**entry, "response": response, "wall_ms": elapsed})
                if index + 1 == len(requests) or requests[index + 1]["phase"] != phase:
                    print(json.dumps({"project": case["project"], "run": output.stem,
                                      "completed_phase": phase, "requests": index + 1}), flush=True)
            process.stdin.close()
            assert process.stdout.read() == ""
            _, status, usage = os.wait4(process.pid, 0)
            process.returncode = os.waitstatus_to_exitcode(status)
            assert process.returncode == 0
            errors.seek(0)
            assert errors.read() == ""
        finally:
            # Popen owns this live child; no PID-only external signaling.
            if process.returncode is None:
                process.terminate()
                process.wait()
            process.stdout.close()
            if not process.stdin.closed:
                process.stdin.close()
    wall_ms = (time.perf_counter() - started) * 1000
    result = {"project": case["project"], "wall_ms": wall_ms,
              "cpu_ms": (usage.ru_utime + usage.ru_stime) * 1000,
              "peak_rss_mib": usage.ru_maxrss / 1024,
              "measurement_scope": "One Linux resident CLI process with no children. Whole session includes process startup, transport, learning, generation, recall, feedback and recovery. Host orchestration and application capture are excluded.",
              "requests": rows, "child_exit_confirmed": True}
    write(output, result)
    return result


def run(cases_path, output):
    output.mkdir(parents=True, exist_ok=False)
    cases = json.loads(cases_path.read_text())["cases"]
    pinned = json.loads((ROOT / "bridge/marvosa/UPSTREAM.json").read_text())["marvosa"]["files_sha256"]
    for name, expected in pinned.items():
        assert sha(ROOT / "bridge/marvosa/vendor" / name) == expected
    protocol = {"kind": "native-hcl-ai-production-cli-v1", "cases_sha256": sha(cases_path),
                "production_adapter_sha256": sha(ROOT / "bridge/marvosa/native_ai.py"),
                "production_scheduler_sha256": sha(ROOT / "bridge/marvosa/native_refresh.py"),
                "entrypoint_sha256": sha(ROOT / "scripts/hcl-ai.py"),
                "baseline_adapter_sha256": sha(SNAPSHOTS / "before-native-ai.py.txt"),
                "baseline_entrypoint_sha256": sha(SNAPSHOTS / "before-hcl-ai.py.txt"),
                "native_sources": pinned, "external_model_calls": 0,
                "model_tokens": "unmeasured", "timing_repetitions": 1,
                "requests": {case["project"]: requests_for(case) for case in cases},
                "scope": "Actual public JSON-lines CLI on both sides, with no scheduler flag, substituted native methods, simulated providers or mocked responses. The baseline uses the previously shipped .4 adapter and entrypoint. Complete real observations are the input. Source completions are already-experienced material; probes share normal live application state."}
    write(output / "protocol.json", protocol)
    summaries = []
    with tempfile.TemporaryDirectory(prefix="rea-native-before-") as directory:
        baseline = Path(directory)
        (baseline / "scripts").mkdir()
        (baseline / "bridge/marvosa").mkdir(parents=True)
        shutil.copy2(SNAPSHOTS / "before-native-ai.py.txt", baseline / "bridge/marvosa/native_ai.py")
        shutil.copy2(SNAPSHOTS / "before-hcl-ai.py.txt", baseline / "scripts/hcl-ai.py")
        shutil.copy2(ROOT / "bridge/marvosa/UPSTREAM.json", baseline / "bridge/marvosa/UPSTREAM.json")
        shutil.copytree(ROOT / "bridge/marvosa/vendor", baseline / "bridge/marvosa/vendor",
                        ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
        for case in cases:
            requests = protocol["requests"][case["project"]]
            before = session(baseline, requests, case, output / (case["project"] + "-before.json"))
            after = session(ROOT, requests, case, output / (case["project"] + "-integrated.json"))
            for index, (left, right) in enumerate(zip(before["requests"], after["requests"])):
                assert left["response"] == right["response"], (case["project"], index, "response changed")
            phase_cost = {}
            for phase in dict.fromkeys(row["phase"] for row in requests):
                a = sum(row["wall_ms"] for row in before["requests"] if row["phase"] == phase)
                b = sum(row["wall_ms"] for row in after["requests"] if row["phase"] == phase)
                phase_cost[phase] = {"before_wall_ms": a, "integrated_wall_ms": b, "ratio": a / b}
            summary = {"project": case["project"], "identical_responses": len(requests),
                       "exact_records_recovered_twice": len(case["records"]),
                       "before": {key: before[key] for key in ("wall_ms", "cpu_ms", "peak_rss_mib")},
                       "integrated": {key: after[key] for key in ("wall_ms", "cpu_ms", "peak_rss_mib")},
                       "whole_session_wall_ratio": before["wall_ms"] / after["wall_ms"],
                       "whole_session_cpu_ratio": before["cpu_ms"] / after["cpu_ms"],
                       "phases": phase_cost}
            summaries.append(summary)
            write(output / "summary.json", {"complete": len(summaries) == len(cases), "cases": summaries})
            print(json.dumps(summary), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--cases", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    run(args.cases.resolve(), args.output.resolve())
