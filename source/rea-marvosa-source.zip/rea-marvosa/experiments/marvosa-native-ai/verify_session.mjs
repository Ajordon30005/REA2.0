import assert from "node:assert/strict";
import { constants } from "node:buffer";
import { execFile } from "node:child_process";
import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = fileURLToPath(new URL("../../", import.meta.url));
const cases = JSON.parse(await fs.readFile(process.argv[2], "utf8"));
const records = cases.cases.find((item) => item.project === "joplin").records;
const first = records[0];
const requests = [
  ...records.map((record) => ({
    operation: "experience",
    evidence_id: record.evidence_id,
    text: record.text,
  })),
  { operation: "experience", evidence_id: first.evidence_id, text: first.text },
  { operation: "status" },
  {
    operation: "experience",
    evidence_id: first.evidence_id,
    text: first.text + "tampered",
  },
  { operation: "ask", prompt: "Which database file holds the note body?" },
  { operation: "feedback", evidence_ids: [first.evidence_id] },
  ...records.map((record) => ({
    operation: "get",
    evidence_id: record.evidence_id,
  })),
  { operation: "status" },
];
const child = execFile(
  process.env.REA_MARVOSA_PYTHON ?? "python3",
  ["-I", "-B", path.join(root, "scripts/hcl-ai.py")],
  { maxBuffer: constants.MAX_LENGTH },
  () => {},
);
const completed = new Promise((resolve, reject) => {
  let stdout = "";
  let stderr = "";
  child.stdout.setEncoding("utf8");
  child.stderr.setEncoding("utf8");
  child.stdout.on("data", (data) => {
    stdout += data;
  });
  child.stderr.on("data", (data) => {
    stderr += data;
  });
  child.once("error", reject);
  child.once("close", (code) =>
    code === 0
      ? resolve({ stdout, stderr })
      : reject(new Error(stderr + " exit=" + code)),
  );
});
child.stdin.end(
  requests.map((request) => JSON.stringify(request)).join("\n") + "\n",
);
const { stdout } = await completed;
const replies = stdout
  .trim()
  .split("\n")
  .map((line) => JSON.parse(line));
assert.equal(replies.length, requests.length);
for (let index = 0; index < requests.length; index++) {
  const request = requests[index];
  const response = replies[index];
  if (request.text?.endsWith("tampered")) {
    assert.equal(response.ok, false);
    continue;
  }
  assert.equal(response.ok, true, JSON.stringify(response));
  if (request.operation === "get") {
    assert.equal(
      response.result.text,
      records.find((record) => record.evidence_id === request.evidence_id).text,
    );
  } else if (request.operation === "status") {
    assert.equal(response.result.evidence_records, records.length);
    assert.equal(response.result.mst, false);
    assert.equal(response.result.integrity.intact, true);
    assert.equal(typeof response.result.signature.writhe, "string");
  } else if (request.operation === "feedback")
    assert.equal(response.result.reinforced_in_place, true);
}
assert.equal(replies[records.length].result.new_evidence, false);
console.log(
  JSON.stringify(
    {
      ok: true,
      protocol_requests: requests.length,
      resident_process: true,
      exact_records: records.length,
      duplicate_is_reinforcement: true,
      conflicting_identity_rejected: true,
      learning_continues_after_rejection: true,
      arbitrary_precision_identity_preserved: true,
      native_runtime: replies.at(-1).result,
      child_exit_confirmed: true,
    },
    null,
    2,
  ),
);
