"""Repeated native HCL AI experience, with evaluation isolated from learning.

The protocol is written before workers start. Original sources and the earlier
QA benchmark are unchanged. No model depth, amplitude or stopping rule is set
by this experiment. Pass counts are measurement points, not runtime limits.
"""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import resource
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "bridge/marvosa"))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from benchmark import QUESTIONS
from native_ai import ResidentHCLAI, wire_value
from native_refresh import NativeRefreshBatch

ARMS = ("repeat_training", "native_interaction", "readable_native_interaction")
CHECKPOINTS = (0, 1, 2, 4, 8)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write(path, value):
    path.write_text(json.dumps(wire_value(value), ensure_ascii=False, indent=2) + "\n")


def clock():
    usage = resource.getrusage(resource.RUSAGE_SELF)
    return (time.perf_counter(), usage.ru_utime + usage.ru_stime)


def elapsed(start):
    now = clock()
    return {"wall_ms": (now[0] - start[0]) * 1000,
            "cpu_ms": (now[1] - start[1]) * 1000}


def state_identity(ai):
    """Include traces, amplitudes, access markers and original byte records."""
    value = {"depth": ai.model.w, "terms": ai.model.memory.vm._terms,
             "signature": ai.model.memory.signature(),
             "accessed": sorted(ai.model.memory.accessed),
             "sigs": ai.model.memory.sigs, "evidence": ai._evidence}
    return digest(json.dumps(wire_value(value), sort_keys=True, default=sorted).encode())


def make_probes(case):
    probes = []
    for record in case["records"]:
        words = record["record"]["normalized_result"]["description"].split()
        split = len(words) // 2
        probes.append({"key": record["key"], "evidence_id": record["evidence_id"],
                       "prompt": " ".join(words[:split]),
                       "expected_continuation": " ".join(words[split:])})
    return probes


def learn(ai, operation, args):
    if operation == "experience":
        # The production adapter owns its complete-turn scheduling now.
        return ai.experience(*args), None
    with NativeRefreshBatch(ai.model.memory) as batch:
        result = ai.model.interact(*args, persist=False)
    return result, batch.receipt()


def generation(ai, prompt):
    # Each probe starts from the same trained state. Neither test prompts nor
    # their generated traces can affect another probe or subsequent training.
    started = clock()
    isolated = copy.deepcopy(ai)
    copied = elapsed(started)
    started = clock()
    response, refreshes = learn(isolated, "interact", (prompt,))
    cost = elapsed(started)
    assert response["bit_perfect"] and response["integrity"]["intact"]
    prefix = " ".join(prompt.split())
    answer = response["answer"]
    assert answer == prefix or answer.startswith(prefix + " ")
    return {"answer": answer, "generated_continuation": answer[len(prefix):].strip(),
            "thinking_depths": response["thinking"], "bit_perfect": True,
            "query_cost": cost, "evaluation_copy_cost": copied, "refreshes": refreshes}


def sequence_grade(expected, generated):
    target, actual = expected.split(), generated.split()
    matched = 0
    for index, word in enumerate(target):
        if index >= len(actual):
            break
        # Predeclared boundary equivalence: a source description in the raw
        # normalized JSON ends in a closing quote and comma. Allow precisely
        # that suffix on the final word for content-order scoring. Clean answer
        # scoring below still requires the exact natural sentence and no tail.
        allowed = {word, word + '\",'} if index == len(target) - 1 else {word}
        if actual[index] not in allowed:
            break
        matched += 1
    return {"ordered_content_complete": matched == len(target),
            "clean_complete_answer": generated == expected,
            "correct_words_before_first_error": matched,
            "expected_words": len(target),
            "ordered_prefix_fraction": matched / len(target)}


def evaluate(ai, case, probes, pass_number):
    started = clock()
    unchanged = state_identity(ai)
    sequences = []
    for probe in probes:
        result = generation(ai, probe["prompt"])
        sequences.append({**probe, **result,
                          **sequence_grade(probe["expected_continuation"], result["generated_continuation"])})
    questions = []
    for index, (prompt, keys, expected) in enumerate(QUESTIONS[case["project"]]):
        result = generation(ai, prompt)
        continuation = result["generated_continuation"]
        correct = bool(continuation) and all(word.casefold() in continuation.casefold() for word in expected)
        questions.append({"prompt": prompt, "expected_keys": keys,
                          "expected_substrings": expected, "generation_correct": correct,
                          "previously_held_out_question": index >= 4, **result})
    exact = all(ai.get(record["evidence_id"]) == record["text"] for record in case["records"])
    assert exact and state_identity(ai) == unchanged
    return {"completed_extra_passes": pass_number, "runtime": ai.status(),
            "ordered_content_complete": sum(row["ordered_content_complete"] for row in sequences),
            "clean_complete_answers": sum(row["clean_complete_answer"] for row in sequences),
            "sequence_probes": len(sequences),
            "mean_ordered_prefix_fraction": sum(row["ordered_prefix_fraction"] for row in sequences) / len(sequences),
            "untrained_question_answers_correct": sum(row["generation_correct"] for row in questions),
            "untrained_questions": len(questions),
            "exact_evidence_retained": len(case["records"]),
            "evaluation_did_not_change_learner": True,
            "sequences": sequences, "questions": questions, "evaluation_cost": elapsed(started)}


def worker(cases_path, project, arm, output):
    case = next(case for case in json.loads(cases_path.read_text())["cases"] if case["project"] == project)
    started = clock()
    ai = ResidentHCLAI()
    for record in case["records"]:
        learn(ai, "experience", (record["evidence_id"], record["text"]))
    training_cost = elapsed(started)
    result = {"project": project, "arm": arm, "initial_ingestion_cost": training_cost,
              "passes": [], "checkpoints": [], "process_family_members": 1,
              "source_hashes_verified": True, "external_model_calls": 0,
              "native_refresh_scheduling": True}
    initial = evaluate(ai, case, make_probes(case), 0)
    initial["cumulative_training_cost"] = dict(training_cost)
    result["checkpoints"].append(initial)
    write(output, result)
    for pass_number in range(1, max(CHECKPOINTS) + 1):
        started = clock()
        before = ai.model.w
        turns = []
        for record in case["records"]:
            text = record["record"]["normalized_result"]["description"] if arm == "readable_native_interaction" else record["text"]
            turn_started = clock()
            if arm == "repeat_training":
                receipt, refreshes = learn(ai, "experience", (record["evidence_id"], text))
                details = {"stored": receipt["learning"]["stored"],
                           "reinforced": receipt["learning"]["reinforced"]}
            else:
                response, refreshes = learn(ai, "interact", (text,))
                assert response["bit_perfect"] and response["integrity"]["intact"]
                details = {"answer": response["answer"], "thinking_depths": response["thinking"]}
            turns.append({"key": record["key"], "whole_input_bytes": len(text.encode()),
                          "depth_after": ai.model.w, "refreshes": refreshes,
                          **details, **elapsed(turn_started)})
        cost = elapsed(started)
        training_cost = {key: training_cost[key] + cost[key] for key in cost}
        result["passes"].append({"number": pass_number, "depth_before": before,
                                 "depth_after": ai.model.w, "training_cost": cost, "turns": turns})
        if pass_number in CHECKPOINTS:
            checkpoint = evaluate(ai, case, make_probes(case), pass_number)
            checkpoint["cumulative_training_cost"] = dict(training_cost)
            result["checkpoints"].append(checkpoint)
        result["total_training_cost"] = dict(training_cost)
        result["peak_worker_rss_bytes"] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * (1 if sys.platform == "darwin" else 1024)
        result["peak_rss_scope"] = "Single worker including isolated evaluation copies; not learner-only RAM."
        write(output, result)
        recent = result["checkpoints"][-1]
        print(json.dumps({"project": project, "arm": arm, "pass": pass_number,
                          "depth": ai.model.w, "live_traces": len(ai.model.memory.vm._terms),
                          "pass_training_ms": cost["wall_ms"],
                          "latest_evaluated_pass": recent["completed_extra_passes"],
                          "ordered": recent["ordered_content_complete"],
                          "clean": recent["clean_complete_answers"],
                          "questions": recent["untrained_question_answers_correct"]}), flush=True)
    result["completed"] = True
    write(output, result)


def orchestrate(cases_path, output):
    output.mkdir(parents=True, exist_ok=False)
    cases = json.loads(cases_path.read_text())["cases"]
    protocol = {"kind": "native-hcl-ai-development-v4-production-refresh",
                "cases_sha256": digest(cases_path.read_bytes()),
                "experiment_script_sha256": digest(Path(__file__).read_bytes()),
                "refresh_scheduler_sha256": digest((ROOT / "bridge/marvosa/native_refresh.py").read_bytes()),
                "production_adapter_sha256": digest((ROOT / "bridge/marvosa/native_ai.py").read_bytes()),
                "native_refresh_scheduling": True,
                "refresh_scheduling_scope": "The production experience adapter owns native refresh scheduling. Direct native interactions in this measurement use the same production scheduler. Every complete turn finishes its original native recomposition before observation. All five original native sources are unchanged.",
                "arms": list(ARMS), "extra_pass_checkpoints": CHECKPOINTS,
                "training": "All arms first ingest every complete normalized record once. Repeated training calls the existing experience adapter. Native interaction calls unmodified interact on every whole record. Readable interaction instead calls interact on each complete verified description; all raw evidence is still retained.",
                "native_contract": "Native talk.py interact behavior; no added decay, manual depth/amplitude settings, MST or runtime generation cap.",
                "evaluation": "Every probe runs on its own deep copy; learner state identity checked before and after each checkpoint. Evaluation supplies no additional target text or correctness feedback to the learner. Completion targets are deliberately part of the experienced source descriptions; English question-answer pairs are never taught.",
                "sequence_grading": "First half of each source description is the prompt; the entire remaining half must appear in order. Content score permits only the raw JSON closing quote/comma on the last word. Clean score requires exact continuation with no extra text.",
                "untrained_question_grading": "Frozen eight English questions from the earlier experiment, scored on generated continuation using the same expected substrings; no retrieval credit.",
                "probes": {case["project"]: make_probes(case) for case in cases},
                "questions": QUESTIONS,
                "limitations": ["Source continuation measures learned ordering, not novel problem solving.",
                                "Repeat-training control stays at its naturally initial depth because it performs no generation in the learner.",
                                "Readable interaction changes the representation and byte count of additional experience; compare its accuracy and actual cost, not equal pass counts alone.",
                                "Exact evidence retention is separate from retaining language-generation skill.",
                                "One deterministic run per condition; no standard-AI or plain-REA baseline; eight extra passes do not establish a developmental ceiling."]}
    write(output / "protocol.json", protocol)
    results = []
    for case in cases:
        for arm in ARMS:
            destination = output / (case["project"] + "-" + arm + ".json")
            command = [sys.executable, "-I", "-B", str(Path(__file__).resolve()),
                       "--worker", "--cases", str(cases_path), "--project", case["project"],
                       "--arm", arm, "--output", str(destination)]
            subprocess.run(command, check=True)
            results.append(json.loads(destination.read_text()))
    write(output / "development.json", {"protocol": protocol, "results": results})


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--cases", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--worker", action="store_true")
    parser.add_argument("--project", choices=QUESTIONS)
    parser.add_argument("--arm", choices=ARMS)
    args = parser.parse_args()
    if args.worker:
        worker(args.cases.resolve(), args.project, args.arm, args.output.resolve())
    else:
        orchestrate(args.cases.resolve(), args.output.resolve())
