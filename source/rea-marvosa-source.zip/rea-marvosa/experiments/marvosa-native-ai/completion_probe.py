"""Additional native continuation lane; does not replace the frozen QA test.

Every observed description is probed automatically with its final word held
back. These are trained-corpus continuations, not unseen semantic questions.
"""
import argparse
import json
from pathlib import Path
import resource
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "bridge/marvosa"))
from native_ai import ResidentHCLAI


def run(cases, output):
    results = []
    for case in json.loads(cases.read_text())["cases"]:
        ai = ResidentHCLAI()
        for record in case["records"]:
            ai.experience(record["evidence_id"], record["text"])
        probes = []
        for record in case["records"]:
            description = record["record"]["normalized_result"]["description"]
            words = description.split()
            prefix, expected = " ".join(words[:-1]), words[-1]
            started = time.perf_counter()
            result = ai.model.interact(prefix, persist=False)
            assert result["bit_perfect"] and result["integrity"]["intact"]
            generated = result["answer"][len(prefix):].strip() if result["answer"].startswith(prefix) else result["answer"]
            probes.append({"evidence_id": record["evidence_id"], "prefix": prefix,
                           "expected_next_word": expected, "generated_continuation": generated,
                           "correct_next_word": bool(generated) and generated.split()[0] == expected,
                           "elapsed_ms": (time.perf_counter()-started)*1000,
                           "bit_perfect": result["bit_perfect"]})
        results.append({"project": case["project"], "correct_next_word": sum(item["correct_next_word"] for item in probes),
                        "probes": probes, "runtime": ai.status()})
        print(json.dumps({"project": case["project"], "native_completion_correct": results[-1]["correct_next_word"], "total": len(probes)}), flush=True)
    output.write_text(json.dumps({"scope": "Native HCL AI completion of experienced observation descriptions; no MST, no unseen-reasoning claim.",
                                  "results": results, "peak_rss_kib": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}, ensure_ascii=False, indent=2)+"\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--cases", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    run(args.cases.resolve(), args.output.resolve())
