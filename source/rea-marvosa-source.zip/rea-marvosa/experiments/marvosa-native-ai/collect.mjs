import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import fs from "node:fs/promises";
import path from "node:path";
import { createRequire } from "node:module";
import { fileURLToPath, pathToFileURL } from "node:url";

const root = fileURLToPath(new URL("../../", import.meta.url));
const work = path.resolve(process.argv[2]);
const reuseAnalysis = process.argv.includes("--reuse-analysis");
const require = createRequire(path.join(root, "package.json"));
const { Client } = await import(
  pathToFileURL(require.resolve("@modelcontextprotocol/client")).href
);
const { StdioClientTransport } = await import(
  pathToFileURL(require.resolve("@modelcontextprotocol/client/stdio")).href
);
const { createEvidence } = await import(
  pathToFileURL(path.join(root, "dist/domain/evidence.js")).href
);
const { createEvidenceBundle } = await import(
  pathToFileURL(path.join(root, "dist/domain/evidenceBundle.js")).href
);
const hash = (value) => createHash("sha256").update(value).digest("hex");
const save = async (name, data) => {
  await fs.writeFile(
    path.join(work, name),
    JSON.stringify(data, null, 2) + "\n",
  );
};
const client = new Client({
  name: "rea-native-hcl-ai-open-source",
  version: "1",
});
const transport = new StdioClientTransport({
  command: process.execPath,
  args: [path.join(root, "scripts/rea.mjs"), "mcp"],
  stderr: "pipe",
});
transport.stderr?.on("data", (data) => process.stderr.write(data));
const calls = [];
let tools;
const call = async (name, args) => {
  const started = performance.now();
  const definition = tools.tools.find((tool) => tool.name === name);
  assert(definition, "Missing advertised tool: " + name);
  const response = await client.callTool({ name, arguments: args }, undefined, {
    timeout: 600000,
    toolDefinition: definition,
  });
  assert.notEqual(response.isError, true, JSON.stringify(response));
  calls.push({ name, elapsed_ms: performance.now() - started });
  console.log(JSON.stringify(calls.at(-1)));
  return response.structuredContent;
};
const sourcePaths = [
  "main.js",
  "command-ls.js",
  "command-set.js",
  "command-export.js",
  "command-tag.js",
  "command-rmnote.js",
  "command-restore.js",
];
const target = path.join(work, "joplin/node_modules/joplin");
const sourceManifest = [];
for (const relative of sourcePaths) {
  const data = await fs.readFile(path.join(target, relative));
  sourceManifest.push({
    path: relative,
    bytes: data.length,
    sha256: hash(data),
  });
}
if (reuseAnalysis) {
  assert.deepEqual(
    JSON.parse(
      await fs.readFile(path.join(work, "joplin-source-manifest.json"), "utf8"),
    ),
    sourceManifest,
  );
} else await save("joplin-source-manifest.json", sourceManifest);
try {
  let summary;
  if (reuseAnalysis)
    summary = JSON.parse(
      await fs.readFile(path.join(work, "joplin-rea-summary.json"), "utf8"),
    );
  else {
    await client.connect(transport);
    tools = await client.listTools();
    summary = await call("analyze_javascript_application", {
      input_path: target,
      format: "directory",
      source_paths: sourcePaths,
      detail: "summary",
    });
    await save("joplin-rea-summary.json", summary);
    await call("export_evidence_bundle", {
      path: path.join(work, "joplin-rea-analysis.json"),
    });
  }
  const cases = [];
  const evidence = [];
  for (const [project, filename, artifact] of [
    [
      "joplin",
      "joplin-case/observations.json",
      "joplin-case/profile/database.sqlite",
    ],
    ["sqlite", "sqlite/observations.json", "sqlite/investigation.sqlite"],
  ]) {
    const observation = JSON.parse(
      await fs.readFile(path.join(work, filename), "utf8"),
    );
    const artifactPath = path.join(work, artifact);
    const digest = hash(await fs.readFile(artifactPath));
    const records = observation.records.map((record) => {
      const item = createEvidence(
        { path: artifactPath, sha256: digest, format: "file" },
        {
          id: "real-open-source-application-probe",
          name: "Actual application and independent database checks",
          version: "1",
        },
        {
          operation: record.operation,
          parameters: { project, observation_key: record.key },
          result: {
            description: record.description,
            observed: record.observed,
          },
          confidence: record.confidence,
          authority: "controlled-replay",
          evidenceLinks:
            project === "joplin"
              ? [summary.normalized_result.parent_evidence_id]
              : [],
          limitations: [
            project === "joplin"
              ? "Executed Joplin terminal application, not the desktop GUI."
              : "Executed the installed SQLite runtime through Python sqlite3.",
          ],
        },
      );
      evidence.push(item);
      return {
        key: record.key,
        evidence_id: item.evidence_id,
        text: JSON.stringify(item.normalized_result, null, 2),
        record: item,
      };
    });
    cases.push({
      project,
      target: observation.target,
      version: observation.version,
      checks_passed: observation.checks_passed,
      artifact: { path: artifactPath, sha256: digest },
      records,
    });
  }
  await save("native-ai-cases.json", { cases });
  await save("application-probe-evidence.json", createEvidenceBundle(evidence));
  console.log(
    JSON.stringify({
      cases: cases.map((item) => ({
        project: item.project,
        records: item.records.length,
        version: item.version,
      })),
    }),
  );
} finally {
  await client.close();
  if (!reuseAnalysis) await save("rea-calls.json", calls);
}
