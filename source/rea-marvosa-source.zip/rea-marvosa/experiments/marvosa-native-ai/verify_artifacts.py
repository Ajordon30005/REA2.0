"""Whole actual database/WAL inputs through the original HCL AI I/O organ."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "bridge/marvosa"))
from native_ai import load_native_ai


def run(work):
    load_native_ai()
    io = sys.modules["juj"]
    results = []
    for relative in ["joplin-case/profile/database.sqlite", "sqlite/investigation.sqlite", "sqlite/active-wal.bin"]:
        raw = (work / relative).read_bytes()
        started = time.perf_counter()
        signature = io.bytes_to_hvp(raw)
        encoded = time.perf_counter()
        recovered = io.hvp_to_bytes(signature, verify=True)
        finished = time.perf_counter()
        assert recovered == raw
        results.append({"path": relative, "bytes": len(raw), "whole_records": 1,
                        "sha256": hashlib.sha256(raw).hexdigest(), "exact": True,
                        "encode_ms": (encoded-started)*1000, "decode_verified_ms": (finished-encoded)*1000})
    (work / "artifact-roundtrips.json").write_text(json.dumps({"results": results}, indent=2)+"\n")
    print(json.dumps({"actual_artifacts": len(results), "all_exact": True, "bytes": sum(item["bytes"] for item in results)}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("work", type=Path)
    run(parser.parse_args().work.resolve())
