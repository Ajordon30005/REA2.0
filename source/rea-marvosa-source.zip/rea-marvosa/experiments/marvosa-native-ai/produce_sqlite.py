"""Real SQLite behavioral observations, with independent assertions."""
import argparse
import hashlib
import json
from pathlib import Path
import sqlite3
import struct
import time


def run(work):
    output = work / "sqlite"
    output.mkdir(parents=True, exist_ok=False)
    path = output / "investigation.sqlite"
    start = time.perf_counter()
    db = sqlite3.connect(path, isolation_level=None)
    db.execute("PRAGMA page_size=4096")
    db.execute("PRAGMA foreign_keys=ON")
    db.execute("CREATE TABLE notebooks(id INTEGER PRIMARY KEY, name TEXT UNIQUE)")
    db.execute("CREATE TABLE notes(id INTEGER PRIMARY KEY, notebook_id INTEGER REFERENCES notebooks(id), title TEXT, body TEXT)")
    db.execute("INSERT INTO notebooks VALUES(1, 'Field research')")
    db.execute("INSERT INTO notes VALUES(1,1,'Lunar calibration','Möbius 検索 🧠')")
    records = []

    def record(key, description, observed):
        records.append({"key": key, "operation": "probe_sqlite_" + key,
                        "confidence": "observed", "description": description,
                        "observed": observed})

    version = db.execute("SELECT sqlite_version(), sqlite_source_id()").fetchone()
    record("identity", "Identity of the real SQLite runtime used for this investigation.",
           {"version": version[0], "source_id": version[1], "binding": "Python sqlite3"})
    db.execute("BEGIN")
    db.execute("UPDATE notes SET body='rollback-canary' WHERE id=1")
    inside = db.execute("SELECT body FROM notes WHERE id=1").fetchone()[0]
    db.execute("ROLLBACK")
    after = db.execute("SELECT body FROM notes WHERE id=1").fetchone()[0]
    assert inside == "rollback-canary" and after == "Möbius 検索 🧠"
    record("rollback", "Rolling back an explicit transaction restores the previous note body.",
           {"inside_transaction": inside, "after_rollback": after})
    db.execute("BEGIN")
    db.execute("UPDATE notes SET title='Committed constellation' WHERE id=1")
    db.execute("COMMIT")
    reader = sqlite3.connect(path, isolation_level=None)
    title = reader.execute("SELECT title FROM notes WHERE id=1").fetchone()[0]
    assert title == "Committed constellation"
    record("commit", "An explicit commit makes the changed title visible to a separate connection.",
           {"second_connection_title": title})
    reader.close()
    try:
        db.execute("INSERT INTO notes VALUES(2,999,'Orphan','not permitted')")
    except sqlite3.IntegrityError as error:
        foreign_error = str(error)
    else:
        raise AssertionError("Foreign-key violation was accepted")
    assert db.execute("SELECT count(*) FROM notes WHERE notebook_id=999").fetchone()[0] == 0
    record("foreign_keys", "With foreign_keys enabled, an orphan note is rejected and not retained.",
           {"error": foreign_error, "orphan_count": 0})
    db.execute("BEGIN")
    db.execute("INSERT INTO notes VALUES(2,1,'Outer survivor','outer')")
    db.execute("SAVEPOINT nested")
    db.execute("INSERT INTO notes VALUES(3,1,'Inner discarded','inner')")
    db.execute("ROLLBACK TO nested")
    db.execute("RELEASE nested")
    db.execute("COMMIT")
    titles = [row[0] for row in db.execute("SELECT title FROM notes ORDER BY id")]
    assert "Outer survivor" in titles and "Inner discarded" not in titles
    record("savepoint", "Rolling back to a savepoint discards inner changes and preserves the outer insertion.",
           {"committed_titles": titles, "discarded_title": "Inner discarded"})
    mode = db.execute("PRAGMA journal_mode=WAL").fetchone()[0]
    assert mode == "wal"
    db.execute("PRAGMA wal_autocheckpoint=0")
    reader = sqlite3.connect(path, isolation_level=None)
    reader.execute("BEGIN")
    before_count = reader.execute("SELECT count(*) FROM notes").fetchone()[0]
    db.execute("INSERT INTO notes VALUES(4,1,'New WAL arrival','fresh')")
    during_count = reader.execute("SELECT count(*) FROM notes").fetchone()[0]
    reader.execute("COMMIT")
    after_count = reader.execute("SELECT count(*) FROM notes").fetchone()[0]
    assert during_count == before_count and after_count == before_count + 1
    wal = Path(str(path) + "-wal")
    wal_bytes = wal.read_bytes()
    (output / "active-wal.bin").write_bytes(wal_bytes)
    record("wal_snapshot", "A WAL reader retains its transaction snapshot until it commits and starts a new read.",
           {"journal_mode": mode, "before_count": before_count,
            "during_count": during_count, "after_count": after_count,
            "wal_exists": wal.exists(), "wal_bytes": len(wal_bytes)})
    checkpoint = db.execute("PRAGMA wal_checkpoint(TRUNCATE)").fetchone()
    assert checkpoint[0] == 0 and wal.stat().st_size == 0
    record("checkpoint", "A successful TRUNCATE checkpoint leaves an empty WAL file in this no-reader case.",
           {"checkpoint_result": list(checkpoint), "wal_bytes_after": wal.stat().st_size})
    reader.close()
    db.execute("CREATE VIRTUAL TABLE notes_fts USING fts5(title, body)")
    db.execute("INSERT INTO notes_fts SELECT title,body FROM notes")
    matches = [row[0] for row in db.execute("SELECT title FROM notes_fts WHERE notes_fts MATCH 'constellation'")]
    assert matches == ["Committed constellation"]
    record("full_text", "An FTS5 query for constellation returns the committed note title.",
           {"query": "constellation", "titles": matches})
    db.execute("CREATE INDEX notes_notebook ON notes(notebook_id)")
    plan = [list(row) for row in db.execute("EXPLAIN QUERY PLAN SELECT title FROM notes WHERE notebook_id=1")]
    assert any("notes_notebook" in row[3] for row in plan)
    record("index", "The query planner uses notes_notebook for the notebook_id equality query.",
           {"query_plan": plan})
    db.close()
    raw = path.read_bytes()
    assert raw[:16] == b"SQLite format 3\x00"
    page_size = struct.unpack(">H", raw[16:18])[0]
    assert page_size == 4096
    reopened = sqlite3.connect(path)
    check = reopened.execute("PRAGMA integrity_check").fetchone()[0]
    unicode_value = reopened.execute("SELECT body FROM notes WHERE id=1").fetchone()[0]
    reopened.close()
    assert check == "ok" and unicode_value == "Möbius 検索 🧠"
    record("file_header", "The actual database has a SQLite format 3 header and 4096-byte pages.",
           {"magic_hex": raw[:16].hex(), "page_size": page_size,
            "file_bytes": len(raw), "integrity_check": check,
            "sha256": hashlib.sha256(raw).hexdigest()})
    record("unicode", "Unicode text survives transaction rollback, checkpoint, closure and reopening exactly.",
           {"reopened_body": unicode_value})
    result = {"target": "SQLite", "version": version[0], "license": "public domain",
              "records": records, "elapsed_ms": (time.perf_counter()-start)*1000,
              "checks_passed": len(records), "real_runtime": True}
    (output / "observations.json").write_text(json.dumps(result, ensure_ascii=False, indent=2)+"\n")
    print(json.dumps({"target": "SQLite", "version": version[0], "checks": len(records), "path": str(path)}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("work", type=Path)
    run(parser.parse_args().work.resolve())
