# Reproduce the native HCL AI comparison

This experiment uses original native HCL AI, actual Joplin CLI workflows and a real SQLite runtime. It includes captured inputs and outputs so native AI replay does not require another application installation. The [results report](../../docs/native-hcl-ai-results.md) describes scope, timings, correct-evidence rankings and failed generated answers.

## Replay the captured AI workloads

Python 3.10+ and the vendored native sources are sufficient. Use a new writable output directory:

```sh
python3 -I -B experiments/marvosa-native-ai/benchmark.py \
  --cases experiments/marvosa-native-ai/results/cases.json \
  --output /absolute/path/new-comparison
node experiments/marvosa-native-ai/verify_session.mjs \
  experiments/marvosa-native-ai/results/cases.json
```

The native AI run makes no model/API calls and does not write the original organism's `memory.hcl` or lifebook. Each worker owns a new model, and resident conditions retain that same model across eight questions. The four held-out questions receive no answer-key feedback. The question-answer grading pairs are kept outside the initial experiences; the observations contain the facts needed to answer. Each evidence record is supplied whole, with no indexing or input-size cutoff. Captured input hashes make exact replay distinguishable from a new application capture.

The session verifier uses installed Node.js; the benchmark itself uses Python's standard library and the pinned native engine files. The Unix `resource` measurements used by the benchmark were qualified on Linux. The standalone native AI session does not depend on `resource`.

## Capture fresh application work

First build REA with its normal dependencies, then choose a new absolute case directory. Place the captured `joplin-install-package.json` and `joplin-install-lock.json` in `CASE/joplin` as `package.json` and `package-lock.json`, and install with `npm ci --prefix CASE/joplin --no-audit --no-fund`. These pin Joplin CLI 3.7.1 and its dependencies.

On the qualified Linux x64 glibc host, normal installation failed in keytar's prebuild ownership handling and source fallback lacked pkg-config/libsecret development files. Joplin's original Linux CLI disables keychain use, so no keytar replacement was required. We installed the unchanged npm dependency files with `--ignore-scripts`, then obtained SQLite's original official prebuilt binding and extracted it without archive ownership changes:

```sh
curl -fL https://github.com/TryGhost/node-sqlite3/releases/download/v5.1.6/napi-v6-linux-glibc-x64.tar.gz \
  -o /absolute/path/CASE/sqlite3-prebuilt.tar.gz
mkdir -p /absolute/path/CASE/joplin/node_modules/sqlite3/lib/binding
tar --no-same-owner --no-same-permissions --keep-old-files \
  -xzf /absolute/path/CASE/sqlite3-prebuilt.tar.gz \
  -C /absolute/path/CASE/joplin/node_modules/sqlite3/lib/binding
```

The original prebuilt archive SHA-256 is `d31475a48731bda50747d4187f46f028565e84086473b55e165e9e4447430164`. No application code, SQLite implementation or native binding was substituted. That preparation recipe is platform-specific; use Joplin's supported installation on other hosts.

Then run:

```sh
TURBO_TELEMETRY_DISABLED=1 DO_NOT_TRACK=1 npm run build:cached
python3 -B experiments/marvosa-native-ai/produce_joplin.py /absolute/path/CASE
python3 -B experiments/marvosa-native-ai/produce_sqlite.py /absolute/path/CASE
node experiments/marvosa-native-ai/collect.mjs /absolute/path/CASE
python3 -I -B experiments/marvosa-native-ai/verify_artifacts.py /absolute/path/CASE
python3 -I -B experiments/marvosa-native-ai/benchmark.py \
  --cases /absolute/path/CASE/native-ai-cases.json \
  --output /absolute/path/CASE/comparison
python3 -I -B experiments/marvosa-native-ai/completion_probe.py \
  --cases /absolute/path/CASE/native-ai-cases.json \
  --output /absolute/path/CASE/completion-probe.json
```

Application producers refuse to reuse an existing output folder. Joplin uses only its new test profile and explicitly disables synchronization. Its generated notes are ordinary test data. Capturing again changes IDs, timestamps and database hashes, so compare behavior and grades rather than expecting the original artifact digest. The SQLite producer requires a build with FTS5. It records the actual version and source ID instead of assuming that it matches the captured 3.53.1 runtime.

`collect.mjs` runs REA's actual stdio MCP analysis and creates canonical Evidence for independently asserted application observations. It inventories the Joplin CLI package and analyzes seven selected complete command files. Its retained full static parent is not included in the compact distribution; the summary keeps unexamined files and unknowns explicit. `--reuse-analysis` is available only when the selected source manifest still matches exactly.

The frozen QA comparison and the extra completion diagnostic are distinct. `finalize.py CASE OUTPUT` copies captured application data, preserves exact case-file bytes, serializes native integer metadata safely and adds the explicitly post-hoc JSON-delimiter diagnostic. It does not rerun the model or change the original strict scores.

## Repeated experience and ordering

`development.py` tests the next developmental question without replacing either earlier result:

```sh
python3 -I -B experiments/marvosa-native-ai/development.py \
  --cases experiments/marvosa-native-ai/results/cases.json \
  --output /absolute/path/new-development-run
```

It writes the protocol, source hashes, scoring rules and exact probes before starting any model worker. Every condition initially receives all complete normalized observations. It then measures zero, one, two, four and eight additional passes through the original material. These are experiment measurement points; no native context-depth or generation limit is introduced.

The control repeats the existing `experience` training call. The second condition repeats original `interact` on each whole normalized record, following the native `talk.py` behavior. The third uses the same native interaction with each complete verified description as readable language. Raw evidence remains intact in every condition. The readable condition changes the representation and number of training bytes, so pass counts alone are not equal-compute comparisons. No extra decay is inserted: native `interact` does not call it.

For each source description, the first half is supplied and the model must generate the remaining half in order. These targets are deliberately part of the experienced source text. The content score permits the precise JSON closing quote/comma on the final word; the clean-answer score requires the exact sentence ending with no extra output. The eight original English questions are separately scored with their frozen factual checks. Evaluation supplies no extra target text or correctness feedback to the learner, and English question-answer pairs are never taught. Each probe uses its own deep copy of the same learner, and state identities are checked before and after evaluation. This prevents tests themselves from changing the later learning curve.

Reports retain every training interaction and every scored output, training and evaluation costs separately, naturally grown depth, live trace counts and exact raw-evidence recovery. Worker peak RSS includes evaluation copies and must not be described as learner-only memory. Source completion measures learned ordering; English-question accuracy and byte retention are distinct measures. Eight passes do not establish how far further development could go.

Refresh scheduling is now automatic in the production resident adapter. Native storage and reinforcement still compute each individual trace as before; the native composite/signature refresh runs once at the end of each complete learning turn. Direct native interactions and isolated scoring copies in this measurement use the same production scheduler. The old `--schedule-native-refresh` switch has been removed from the current driver. The original five native files are unchanged.

`verify_native_refresh.py OUTPUT.json` compares the captured `.4` adapter with the integrated production `experience`, `ask`, feedback and recovery methods using complete native state hashes, including all trace amplitudes, composite fields, HVP records and the operation log. It also checks method restoration on exceptions before and after a learning mutation. This comparison uses actual native computation. The original eight-pass Joplin training control is retained separately for comparison with the scheduled control across all five checkpoints.

The complete 540-generation capture is in `results/development/`. Its protocol hash matches `executed-development-source.py.txt`; that source snapshot and the captured results are unchanged. The current driver uses the integrated scheduler and records a new protocol version and adapter hash. Earlier schedules and their interruption status are retained in `measurement-history.json`; they are not counted as completed growth conditions. See the [ordering results](../../docs/native-hcl-ai-results.md#continued-experience-and-order).

## Verify the actual application integration

```sh
python3 -I -B experiments/marvosa-native-ai/verify_production.py \
  --cases experiments/marvosa-native-ai/results/integration/cases.json \
  --output /absolute/path/new-production-verification
```

This Linux driver starts the actual JSON-lines CLI, sends complete case records through its public commands, and checks every response against the captured previous application. It exercises initial and repeated learning, two passes of full-description interaction, source completion, exact recovery, conflict rejection, feedback and recovery afterward. No responses or engines are mocked. The captured `.4` entrypoint and adapter are copied unchanged into a temporary baseline installation using the same five pinned native files. Both child processes exit normally after EOF.

The integration inputs combine a newly executed eleven-check SQLite case with the preserved nine-record Joplin CLI case. Joplin is a replay of actual captured evidence; it was not reinstalled during this integration run. For a fresh SQLite capture, run `produce_sqlite.py` on a new directory as above. The bundled `results/integration/sqlite-observations.json` records the executed checks. Full requests, outputs, source hashes, timings and results are retained under `results/integration/`.
