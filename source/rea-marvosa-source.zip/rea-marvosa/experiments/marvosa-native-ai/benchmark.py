"""Predeclared comparison of fresh and resident ORIGINAL native HCL AI.

Each arm runs in a separate Python process. Model code is byte-pinned, the
questions/expected answers are never ingested as experience, and feedback
uses independently checked observations only on the first four questions.
"""
import argparse
import gc
import hashlib
import json
from pathlib import Path
import resource
import statistics
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "bridge/marvosa"))

QUESTIONS = {
    "joplin": [
        ("Which database file and table hold the saved note body?", ["storage"], ["database.sqlite", "notes"]),
        ("Which table links a tag to its assigned note?", ["tags"], ["note_tags"]),
        ("Does renaming a note preserve its identifier and original body?", ["rename"], ["preserv"]),
        ("Which field records that a to-do was completed?", ["todo"], ["todo_completed"]),
        ("Why did the listing return no results for a token present only in the body?", ["title_filter"], ["title"]),
        ("Which exported format kept the Unicode note body in an individual text file?", ["markdown"], ["md"]),
        ("Which archive container holds the exported JEX contents?", ["jex"], ["tar"]),
        ("What is the deletion timestamp after a trashed note is restored?", ["trash_restore"], ["0"]),
    ],
    "sqlite": [
        ("Which note body remains after the explicit transaction is rolled back?", ["rollback"], ["Möbius", "検索"]),
        ("Which title does a separate connection see after the update is committed?", ["commit"], ["Committed constellation"]),
        ("Which error rejects a note whose parent notebook does not exist?", ["foreign_keys"], ["FOREIGN KEY constraint failed"]),
        ("Which newly inserted note survives the nested savepoint rollback?", ["savepoint"], ["Outer survivor"]),
        ("When can the WAL reader observe the new row from the other connection?", ["wal_snapshot"], ["commit"]),
        ("How many bytes remain in the log after its truncate checkpoint?", ["checkpoint"], ["0"]),
        ("Which index is selected for the notebook equality lookup?", ["index"], ["notes_notebook"]),
        ("What page size is encoded in the database file header?", ["file_header"], ["4096"]),
    ],
}
ARMS = ("fresh_each_question", "resident", "resident_verified_feedback")


def snapshot():
    usage = resource.getrusage(resource.RUSAGE_SELF)
    return {"wall": time.perf_counter(), "user": usage.ru_utime, "system": usage.ru_stime}


def worker(case_path, project, arm, destination):
    from native_ai import ResidentHCLAI, wire_value
    case = next(item for item in json.loads(case_path.read_text())["cases"] if item["project"] == project)
    records = case["records"]
    by_key = {record["key"]: record["evidence_id"] for record in records}
    started = snapshot()
    initialization = []
    turns = []

    def initialize():
        before = snapshot()
        instance = ResidentHCLAI()
        receipt = [instance.experience(record["evidence_id"], record["text"]) for record in records]
        for record in records:
            assert instance.get(record["evidence_id"]) == record["text"]
        after = snapshot()
        initialization.append({"wall_ms": (after["wall"]-before["wall"])*1000,
                               "cpu_user_ms": (after["user"]-before["user"])*1000,
                               "cpu_system_ms": (after["system"]-before["system"])*1000,
                               "records": len(receipt), "whole_input_bytes": sum(len(record["text"].encode()) for record in records),
                               "exact_regeneration": True})
        return instance

    ai = None
    if arm != "fresh_each_question":
        ai = initialize()
    for index, (question, keys, expected) in enumerate(QUESTIONS[project]):
        if arm == "fresh_each_question":
            ai = None
            gc.collect()
            ai = initialize()
        before = snapshot()
        response = ai.ask(question, limit=3)
        after = snapshot()
        assert response["bit_perfect"] and response["integrity"]["intact"]
        prefix = " ".join(question.split())
        answer = response["answer"]
        continuation = answer[len(prefix):].strip() if answer.startswith(prefix) else answer
        returned = [row["evidence_id"] for row in response["matches"]]
        relevant = [by_key[key] for key in keys]
        ranks = [returned.index(key)+1 for key in relevant if key in returned]
        grade = bool(continuation) and all(token.casefold() in continuation.casefold() for token in expected)
        turn = {"question": question, "phase": "learning" if index < 4 else "held_out",
                "expected_keys": keys, "expected_evidence_ids": relevant,
                "returned_evidence_ids": returned, "top1_correct": bool(ranks and min(ranks)==1),
                "top3_correct": bool(ranks), "reciprocal_rank_at3": 1/min(ranks) if ranks else 0,
                "answer": answer, "generated_continuation": continuation,
                "continuation_expected_substrings": expected, "generation_correct": grade,
                "bit_perfect": response["bit_perfect"],
                "wall_ms": (after["wall"]-before["wall"])*1000,
                "cpu_user_ms": (after["user"]-before["user"])*1000,
                "cpu_system_ms": (after["system"]-before["system"])*1000}
        if arm == "resident_verified_feedback" and index < 4:
            before_feedback = snapshot()
            turn["feedback"] = ai.feedback(relevant)
            assert turn["feedback"]["reinforced_in_place"]
            turn["feedback_ms"] = (snapshot()["wall"]-before_feedback["wall"])*1000
        turns.append(turn)
    exact = all(ai.get(record["evidence_id"]) == record["text"] for record in records)
    ended = snapshot()
    usage = resource.getrusage(resource.RUSAGE_SELF)
    held_out = [turn for turn in turns if turn["phase"] == "held_out"]
    result = {"project": project, "target_version": case["version"], "arm": arm,
              "runtime": ai.status(), "initializations": initialization, "turns": turns,
              "wall_ms": (ended["wall"]-started["wall"])*1000,
              "cpu_user_ms": (ended["user"]-started["user"])*1000,
              "cpu_system_ms": (ended["system"]-started["system"])*1000,
              "peak_process_family_rss_bytes": usage.ru_maxrss * (1024 if sys.platform != "darwin" else 1),
              "process_family_members": 1, "exact_regeneration_after_turns": exact,
              "held_out_top1": sum(turn["top1_correct"] for turn in held_out),
              "held_out_top3": sum(turn["top3_correct"] for turn in held_out),
              "held_out_generation_correct": sum(turn["generation_correct"] for turn in held_out),
              "held_out_questions": len(held_out),
              "median_query_ms": statistics.median(turn["wall_ms"] for turn in turns),
              "model_tokens": "not measured; this native model uses its own braid/trace representation",
              "external_model_calls": 0,
              "scope": "Original native HCL AI, complete normalized application observations; no expected answers ingested, feedback only on learning turns. This is not a plain-REA baseline."}
    assert exact
    destination.write_text(json.dumps(wire_value(result), ensure_ascii=False, indent=2)+"\n")
    print(json.dumps({key: result[key] for key in ["project", "arm", "wall_ms", "median_query_ms", "held_out_top1", "held_out_top3", "held_out_generation_correct"]}), flush=True)


def orchestrate(case_path, output):
    output.mkdir(parents=True, exist_ok=False)
    results = []
    for project in QUESTIONS:
        for arm in ARMS:
            destination = output / (project + "-" + arm + ".json")
            subprocess.run([sys.executable, "-I", "-B", str(Path(__file__).resolve()),
                            "--worker", "--cases", str(case_path), "--project", project,
                            "--arm", arm, "--output", str(destination)], check=True)
            results.append(json.loads(destination.read_text()))
    report = {"kind": "native-hcl-ai-open-source-comparison", "results": results,
              "cases_sha256": hashlib.sha256(case_path.read_bytes()).hexdigest(),
              "limitations": ["Small predeclared workload: eight related questions per project, four held out from feedback.",
                              "Models receive complete verified normalized observations, not an autonomous tool-use policy.",
                              "Resident control still performs native interact learning; the feedback arm additionally reinforces verified evidence and runs native decay.",
                              "Generation is graded only after removing the echoed question; evidence retrieval is scored separately.",
                              "Peak RSS is the single native worker process; one process per arm. Shared REA collection is outside these timings."]}
    (output / "comparison.json").write_text(json.dumps(report, ensure_ascii=False, indent=2)+"\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--cases", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--worker", action="store_true")
    parser.add_argument("--project", choices=QUESTIONS)
    parser.add_argument("--arm", choices=ARMS)
    args = parser.parse_args()
    if args.worker:
        worker(args.cases.resolve(), args.project, args.arm, args.output.resolve())
    else:
        orchestrate(args.cases.resolve(), args.output.resolve())
