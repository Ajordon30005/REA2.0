import assert from "node:assert/strict";
import fs from "node:fs/promises";
import path from "node:path";
import { createRequire } from "node:module";
import { createHash } from "node:crypto";
import { fileURLToPath, pathToFileURL } from "node:url";
const work = path.resolve(process.argv[3] ?? ".");
const rea = fileURLToPath(new URL("../../", import.meta.url));
const require = createRequire(path.join(rea, "package.json"));
const { Client } = await import(
  pathToFileURL(require.resolve("@modelcontextprotocol/client")).href
);
const { StdioClientTransport } = await import(
  pathToFileURL(require.resolve("@modelcontextprotocol/client/stdio")).href
);
const phase = process.argv[2] || "analyze";
const sha = (value) => createHash("sha256").update(value).digest("hex");
const calls = [];
const save = async (name, value) => {
  const output = path.join(work, name);
  await fs.mkdir(path.dirname(output), { recursive: true });
  await fs.writeFile(output, JSON.stringify(value, null, 2) + "\n");
};
const client = new Client({ name: "notion-real-showcase", version: "1" });
const transport = new StdioClientTransport({
  command: process.execPath,
  args: [path.join(rea, "scripts/rea.mjs"), "mcp"],
  env: Object.fromEntries(
    Object.entries(process.env).filter(([, v]) => typeof v === "string"),
  ),
  stderr: "pipe",
});
transport.stderr?.on("data", (value) => process.stderr.write(value));
const call = async (name, args, filename, allowError = false) => {
  const start = performance.now();
  const response = await client.callTool({ name, arguments: args }, undefined, {
    timeout: 600000,
  });
  const value = response.structuredContent ?? response;
  const elapsed_ms = performance.now() - start;
  calls.push({ name, elapsed_ms, error: response.isError === true });
  if (filename) await save(filename, value);
  console.log(
    JSON.stringify({
      tool: name,
      elapsed_ms: Math.round(elapsed_ms),
      error: response.isError === true,
      filename,
    }),
  );
  if (response.isError && !allowError)
    throw Error(JSON.stringify(response).slice(0, 3000));
  return value;
};
await client.connect(transport);
try {
  if (phase === "analyze") {
    const summary = await call(
      "analyze_javascript_application",
      {
        input_path: path.join(work, "extracted/resources/app.asar"),
        format: "asar",
        source_paths: [".webpack/renderer/tab_browser_view/preload.js"],
        detail: "summary",
      },
      "reports/preload-summary.json",
    );
    const parentId = summary.normalized_result.parent_evidence_id;
    await save("analysis-parent.json", {
      evidence_id: parentId,
      summary_evidence_id: summary.evidence_id,
    });
    await call(
      "export_evidence_bundle",
      { path: path.join(work, "notion-analysis-evidence.json") },
      "reports/analysis-export.json",
    );
    const application = { kind: "retained-evidence", evidence_id: parentId };
    await call(
      "trace_application_feature",
      {
        application,
        seed: { kind: "api", value: "__electronApi", match: "exact" },
        direction: "both",
      },
      "reports/api-trace.json",
      true,
    );
    await call(
      "trace_application_feature",
      {
        application,
        seed: {
          kind: "channel",
          value: "notion:clipboard:write",
          match: "exact",
        },
        direction: "both",
      },
      "reports/legacy-clipboard-channel.json",
      true,
    );
    await call(
      "trace_javascript_semantics",
      {
        application,
        query: {
          seed: { kind: "property", name: "copyText" },
          direction: "forward-influence",
        },
      },
      "reports/copyText-semantic.json",
      true,
    );
    await call(
      "export_evidence_bundle",
      { path: path.join(work, "notion-investigation-evidence.json") },
      "reports/investigation-export.json",
    );
  } else if (phase === "focus") {
    await call(
      "import_evidence_bundle",
      { path: path.join(work, "notion-investigation-evidence.json") },
      "reports/focus-import.json",
    );
    const parent = JSON.parse(
      await fs.readFile(path.join(work, "analysis-parent.json"), "utf8"),
    ).evidence_id;
    const application = { kind: "retained-evidence", evidence_id: parent };
    const trace = await call(
      "trace_application_feature",
      {
        application,
        seed: {
          kind: "api",
          value: "__electronApi.copyText",
          match: "exact",
          entry_path: ["__electronApi", "copyText"],
        },
        direction: "outgoing",
      },
      "reports/copyText-focused-trace.json",
    );
    await save("focused-evidence-id.json", { evidence_id: trace.evidence_id });
    await call(
      "export_evidence_bundle",
      { path: path.join(work, "notion-focused-evidence.json") },
      "reports/focus-export.json",
    );
  } else if (phase === "remember") {
    const bundle = JSON.parse(
      await fs.readFile(
        path.join(work, "notion-focused-evidence.json"),
        "utf8",
      ),
    );
    const sourceBundle = JSON.parse(
      await fs.readFile(
        path.join(work, "source-and-probe-evidence.json"),
        "utf8",
      ),
    );
    const focusedId = JSON.parse(
      await fs.readFile(path.join(work, "focused-evidence-id.json"), "utf8"),
    ).evidence_id;
    const selected = [
      ...bundle.records.filter(
        (record) =>
          record.evidence_id === focusedId ||
          record.operation === "inspect_analysis_view" ||
          record.normalized_result?.seed?.value === "notion:clipboard:write",
      ),
      ...sourceBundle.records,
    ];
    const entries = selected.map((record) => ({
      source:
        "notion:" +
        record.operation +
        ":" +
        (record.normalized_result?.seed?.value ||
          record.subject?.name ||
          "summary"),
      raw_json: JSON.stringify(record),
    }));
    const receipt = await call(
      "hcl_remember_evidence",
      { case_path: path.join(work, "hcl-case"), entries },
      "hcl/receipt.json",
    );
    const original = entries.map((entry, i) => ({
      source: entry.source,
      evidence_id: selected[i].evidence_id,
      record_id: receipt.normalized_result.record_ids[i],
      bytes: Buffer.byteLength(entry.raw_json),
      sha256: sha(entry.raw_json),
    }));
    await save("hcl/original-manifest.json", original);
  } else if (phase === "resume") {
    const original = JSON.parse(
      await fs.readFile(path.join(work, "hcl/original-manifest.json"), "utf8"),
    );
    const case_path = path.join(work, "hcl-case");
    const verified = await call(
      "hcl_verify_case",
      { case_path },
      "hcl/verified-after-process-restart.json",
    );
    const recovered = [];
    for (const record of original) {
      const got = await call("hcl_get_evidence", {
        case_path,
        record_id: record.record_id,
      });
      const value = got.normalized_result;
      assert.equal(sha(value.raw_json), record.sha256);
      assert.equal(value.verified, true);
      const parsed = JSON.parse(value.raw_json);
      if (parsed.operation === "read_notion_preload_source") {
        const source = await fs.readFile(
          path.join(
            work,
            "source/.webpack/renderer/tab_browser_view/preload.js",
          ),
          "utf8",
        );
        assert.equal(parsed.normalized_result.source_text, source);
      }
      recovered.push({ ...record, exact: true });
    }
    const queries = [];
    for (const query of [
      "copyText",
      "navigator.clipboard.writeText",
      "notion:clipboard:write",
    ]) {
      const result = await call(
        "hcl_recall_evidence",
        { case_path, query, limit: 5 },
        "hcl/query-" + queries.length + ".json",
      );
      queries.push({
        query,
        ranked_sources: result.normalized_result.matches.map(
          (match) => match.metadata.source,
        ),
        scores_integer: result.normalized_result.matches.map(
          (match) => match.score_integer,
        ),
      });
    }
    const result = {
      recovered_records: recovered.length,
      recovered_bytes: recovered.reduce((n, row) => n + row.bytes, 0),
      recovered,
      queries,
      verification: verified.normalized_result,
      scope:
        "Separate Node process and stdio MCP server from ingestion. Original byte equality checked independently; original complete source also checked after recovery.",
    };
    await save("notion-case-result.json", result);
    console.log(
      JSON.stringify({
        recovered_records: result.recovered_records,
        recovered_bytes: result.recovered_bytes,
        index_partial: result.verification.records_with_partial_index,
        queries,
      }),
    );
  } else throw Error("Unknown phase");
} finally {
  await client.close();
  await save(`calls-${phase}.json`, calls);
}
