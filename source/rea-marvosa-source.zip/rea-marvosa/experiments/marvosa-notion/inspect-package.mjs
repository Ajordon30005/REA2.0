import fs from "node:fs/promises";
import path from "node:path";
import { createRequire } from "node:module";
import { createHash } from "node:crypto";
import { fileURLToPath, pathToFileURL } from "node:url";
const work = path.resolve(process.argv[2] ?? ".");
const rea = fileURLToPath(new URL("../../", import.meta.url));
const require = createRequire(path.join(rea, "package.json"));
const asar = await import(
  pathToFileURL(require.resolve("@electron/asar")).href
);
const file = path.join(work, "extracted/resources/app.asar");
const entries = asar.listPackage(file);
const packageJson = JSON.parse(
  asar.extractFile(file, "package.json").toString("utf8"),
);
const sources = entries.filter(
  (name) => name.endsWith(".js") && /preload|main\/index|Sqlite/.test(name),
);
const manifest = {
  version: packageJson.version,
  name: packageJson.name,
  bytes: (await fs.stat(file)).size,
  sha256: createHash("sha256")
    .update(await fs.readFile(file))
    .digest("hex"),
  entries: entries.length,
  sources: [],
};
for (const name of sources) {
  const relative = name.replace(/^\//, "");
  if (relative.split("/").includes("..")) throw Error("Invalid packaged path");
  const bytes = asar.extractFile(file, relative);
  const output = path.join(work, "source", relative);
  await fs.mkdir(path.dirname(output), { recursive: true });
  await fs.writeFile(output, bytes);
  manifest.sources.push({
    path: relative,
    bytes: bytes.length,
    sha256: createHash("sha256").update(bytes).digest("hex"),
  });
}
await fs.writeFile(
  path.join(work, "target-manifest.json"),
  JSON.stringify(manifest, null, 2) + "\n",
);
console.log(JSON.stringify(manifest, null, 2));
