import assert from "node:assert/strict";
import fs from "node:fs/promises";
import path from "node:path";
import vm from "node:vm";
import { createHash } from "node:crypto";
import { createRequire } from "node:module";
import { fileURLToPath, pathToFileURL } from "node:url";
const work = path.resolve(process.argv[2] ?? ".");
const rea = fileURLToPath(new URL("../../", import.meta.url));
const require = createRequire(path.join(rea, "package.json"));
const { parse } = await import(
  pathToFileURL(require.resolve("@babel/parser")).href
);
const { createEvidence } = await import(
  pathToFileURL(path.join(rea, "dist/domain/evidence.js")).href
);
const { createEvidenceBundle } = await import(
  pathToFileURL(path.join(rea, "dist/domain/evidenceBundle.js")).href
);
const parent = JSON.parse(
  await fs.readFile(path.join(work, "analysis-parent.json"), "utf8"),
).evidence_id;
const packageVersion = JSON.parse(
  await fs.readFile(path.join(work, "target-manifest.json"), "utf8"),
).version;
const relative = ".webpack/renderer/tab_browser_view/preload.js";
const file = path.join(work, "source", relative);
const text = await fs.readFile(file, "utf8");
const digest = createHash("sha256").update(text).digest("hex");
const ast = parse(text, { sourceType: "unambiguous" });
const candidates = [];
const stack = [ast];
while (stack.length) {
  const node = stack.pop();
  if (
    node?.type === "AssignmentExpression" &&
    node.left.type === "MemberExpression" &&
    !node.left.computed &&
    node.left.property.name === "copyText" &&
    node.right.type === "FunctionExpression"
  )
    candidates.push(node.right);
  if (node && typeof node === "object")
    for (const [key, value] of Object.entries(node)) {
      if (["loc", "start", "end", "extra", "comments", "tokens"].includes(key))
        continue;
      if (Array.isArray(value))
        stack.push(...value.filter((x) => x && typeof x === "object"));
      else if (value && typeof value === "object") stack.push(value);
    }
}
assert.equal(candidates.length, 1);
const fn = candidates[0];
// Admit only the inspected one-return browser API call, not arbitrary package startup.
assert.equal(fn.params.length, 1);
assert.equal(fn.params[0].type, "Identifier");
assert.equal(fn.body.body.length, 1);
const call = fn.body.body[0].argument;
assert.equal(fn.body.body[0].type, "ReturnStatement");
assert.equal(call.type, "CallExpression");
assert.equal(call.callee.type, "MemberExpression");
assert.equal(call.callee.computed, false);
assert.equal(call.callee.property.name, "writeText");
assert.equal(call.callee.object.type, "MemberExpression");
assert.equal(call.callee.object.computed, false);
assert.equal(call.callee.object.object.name, "navigator");
assert.equal(call.callee.object.property.name, "clipboard");
assert.equal(call.arguments.length, 1);
assert.equal(call.arguments[0].type, "Identifier");
assert.equal(call.arguments[0].name, fn.params[0].name);
const originalFunction = text.slice(fn.start, fn.end);
const tests = [];
for (const input of [
  "",
  "Project notes",
  "Möbius 検索 🧠",
  "<p>This remains text</p>",
]) {
  const writes = [];
  const returned = Promise.resolve("browser-result");
  const execute = vm.runInNewContext(
    "(" + originalFunction + ")",
    {
      navigator: {
        clipboard: {
          writeText(value) {
            writes.push(value);
            return returned;
          },
        },
      },
    },
    { timeout: 1000 },
  );
  const result = execute(input);
  assert.equal(result, returned);
  await result;
  assert.deepEqual(writes, [input]);
  tests.push({
    name:
      input === ""
        ? "empty-string"
        : input.startsWith("<")
          ? "html-as-plain-text"
          : input.includes("検索")
            ? "unicode"
            : "plain-text",
    passed: true,
    exact_forwarding: true,
    original_promise_returned: true,
  });
}
const rejection = new Error("clipboard permission denied");
const rejected = vm.runInNewContext(
  "(" + originalFunction + ")",
  {
    navigator: {
      clipboard: {
        writeText() {
          return Promise.reject(rejection);
        },
      },
    },
  },
  { timeout: 1000 },
);
await assert.rejects(rejected("sample"), (error) => error === rejection);
tests.push({ name: "browser-rejection-propagates", passed: true });
const thrown = new Error("synchronous API failure");
const throwing = vm.runInNewContext(
  "(" + originalFunction + ")",
  {
    navigator: {
      clipboard: {
        writeText() {
          throw thrown;
        },
      },
    },
  },
  { timeout: 1000 },
);
assert.throws(
  () => throwing("sample"),
  (error) => error === thrown,
);
tests.push({ name: "synchronous-error-propagates", passed: true });
const target = { path: file, sha256: digest, format: "javascript" };
const result = {
  application: "Notion Desktop",
  version: packageVersion,
  packaged_source: relative,
  source_sha256: digest,
  function_start: fn.start,
  function_end: fn.end,
  source_location: JSON.parse(JSON.stringify(fn.loc)),
  function_sha256: createHash("sha256").update(originalFunction).digest("hex"),
  original_function: originalFunction,
  recovered_route: "__electronApi.copyText -> navigator.clipboard.writeText",
  tests,
  scope:
    "Actual extracted packaged function, executed against an instrumented browser-API boundary; not a running Notion UI or physical OS clipboard session.",
};
const probe = createEvidence(
  target,
  {
    id: "notion-extracted-function-probe",
    name: "Isolated original Notion function",
    version: "1",
  },
  {
    operation: "probe_notion_copy_text",
    parameters: {
      packaged_path: relative,
      function_start: fn.start,
      function_end: fn.end,
    },
    result,
    confidence: "observed",
    authority: "controlled-replay",
    evidenceLinks: [parent],
    limitations: [
      result.scope,
      "The context-bridge exposure is a separate static finding; these checks do not prove live Electron permission behavior.",
    ],
  },
);
const source = createEvidence(
  target,
  {
    id: "notion-packaged-source",
    name: "Exact original shipped JavaScript",
    version: "1",
  },
  {
    operation: "read_notion_preload_source",
    parameters: { packaged_path: relative },
    result: {
      package_version: packageVersion,
      packaged_path: relative,
      source_sha256: digest,
      source_bytes: Buffer.byteLength(text),
      source_text: text,
    },
    confidence: "observed",
    authority: "shipped-artifact",
    evidenceLinks: [parent],
    limitations: ["Source text alone does not prove runtime execution."],
  },
);
await fs.mkdir(path.join(work, "reports"), { recursive: true });
await fs.writeFile(
  path.join(work, "reports/original-function-probe.json"),
  JSON.stringify(probe, null, 2) + "\n",
);
await fs.writeFile(
  path.join(work, "source-and-probe-evidence.json"),
  JSON.stringify(createEvidenceBundle([probe, source])) + "\n",
);
await fs.writeFile(
  path.join(work, "probe-evidence-ids.json"),
  JSON.stringify(
    { source: source.evidence_id, probe: probe.evidence_id },
    null,
    2,
  ) + "\n",
);
console.log(
  JSON.stringify({
    result,
    source_evidence_id: source.evidence_id,
    probe_evidence_id: probe.evidence_id,
  }),
);
