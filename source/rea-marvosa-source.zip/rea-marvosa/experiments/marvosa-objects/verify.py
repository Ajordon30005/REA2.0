#!/usr/bin/env python3
"""Full unchanged sourcemap-codec via public REA CLI and original Node oracle."""
import argparse
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
from decimal import Decimal

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location('qualification', ROOT/'experiments/marvosa-transcription/verify.py')
qualification = importlib.util.module_from_spec(spec)
spec.loader.exec_module(qualification)


def decode(value):
    if isinstance(value, dict):
        if value.get('type') == 'number':
            return Decimal(value['decimal'])
        return {k: decode(v) for k, v in value.items()}
    if isinstance(value, list):
        return [decode(v) for v in value]
    return value


def compare(report, expected):
    calls = report['execution']['calls']
    assert len(calls) == len(expected)
    for i, (actual, wanted) in enumerate(zip(calls, expected)):
        assert actual['status'] == 'completed', (i, actual.get('error'))
        assert decode(actual['value']) == wanted, (i, decode(actual['value']), wanted)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    out = args.output.resolve(); out.mkdir(parents=True, exist_ok=False)
    source_owner = tempfile.TemporaryDirectory(prefix='rea-hcl-object-source-')
    project = Path(source_owner.name)/'inputs'; project.mkdir()
    shutil.copytree(ROOT/'node_modules/@jridgewell/sourcemap-codec', project/'codec')
    shutil.copy2(Path(__file__).with_name('driver.cjs'), project/'driver.cjs')
    (project/'driver-ts.cjs').write_text((project/'driver.cjs').read_text().replace('./codec/dist/sourcemap-codec.umd.js','./codec/src/sourcemap-codec.ts'))
    source_map = ROOT/'node_modules/@jridgewell/resolve-uri/dist/resolve-uri.umd.js.map'
    shutil.copy2(source_map, out/source_map.name)
    shutil.copy2(ROOT/'node_modules/@jridgewell/resolve-uri/LICENSE', out/'resolve-uri.LICENSE')
    mappings = json.loads(source_map.read_text())['mappings']
    calls=[]
    def add(entry, arguments, module='codec/dist/sourcemap-codec.umd.js'):
        calls.append(dict(module=module, entry=entry, arguments_json=json.dumps(arguments)))
    for value in ['', ';', ';;', 'AAAA,CAAC;AACA', ';EAEEA,EAAE,EAAC,CAAE;ECQY,UACC', 'G,C,E', 'D', 'B']:
        add('decode', [value])
    for value in [[], [[]], [[],[],[]], [[[0,0,0,0],[10,1,4,2,3]],[],[[4,0,2,0]]], [[[12],[2],[7]]]]:
        add('encode', [value])
    for value in ['', ';', 'ABC;gBC', 'ggggggB']:
        add('decodeRangeMappings', [value])
    for value in [[], [[]], [[0,1,31,32,1024],[],[0,17,100000]]]:
        add('encodeRangeMappings', [value])
    for value in [[], [{'range':[0,0,8,0,1,2],'vars':[0,4]}, {'range':[1,2,3,5,2],'vars':[1,5]}],
                  [{'range':[3,10,9,2,0],'vars':[]}, {'range':[9,3,10,0,1,0],'vars':[3]}]]:
        add('originalScopes', [value], 'driver.cjs')
    for value in [[], [{'range':[0,0,4,2],'isScope':False,'callsite':None,'bindings':[]}],
                  [{'range':[0,0,8,0,0,1],'isScope':True,'callsite':[0,1,4], 'bindings':[[[0],[1,2,3],[2,4,5]]]},
                   {'range':[1,2,3,4,1,2],'isScope':False,'callsite':[1,3,2], 'bindings':[[[-1]],[[4]]]}]]:
        add('generatedRanges', [value], 'driver.cjs')
    # Whole original source map, including every line and mapping segment.
    add('decode', [mappings])
    calls_path=out/'calls.json'; calls_path.write_text(json.dumps(calls))
    oracle=r'''
const fs=require('fs'),root=process.argv[1],calls=JSON.parse(fs.readFileSync(process.argv[2]));
function project(v) {
  if (Array.isArray(v)) {
    const items=v.map(project),props={};
    for (const k of Object.keys(v)) if(!/^(0|[1-9][0-9]*)$/.test(k)) props[k]=project(v[k]);
    return Object.keys(props).length?{type:'array',items,properties:props}:items;
  }
  if(v && typeof v==='object')return Object.fromEntries(Object.entries(v).map(([k,x])=>[k,project(x)]));
  if(v===undefined)return {type:'undefined'};
  return v;
}
console.log(JSON.stringify(calls.map(c=>project(require(root+'/'+c.module)[c.entry](...JSON.parse(c.arguments_json))))));
'''
    (out/'oracle.cjs').write_text(oracle)
    expected=json.loads(subprocess.check_output(['node','-e',oracle,str(project),str(calls_path)]))
    # Re-encode the complete decoded real map through the HCL graph too.
    add('encode', [expected[-1]])
    expected.append(subprocess.check_output(['node','-e',"const c=require(process.argv[1]);const fs=require('fs');const m=JSON.parse(fs.readFileSync(process.argv[2])).mappings;process.stdout.write(c.encode(c.decode(m)));",str(project/'codec/dist/sourcemap-codec.umd.js'),str(source_map)],text=True))
    assert expected[-1] == mappings
    real_map_call_index=len(calls)-2
    # Execute the untouched TypeScript modules and ESM distribution as well.
    # Their reference is this package's independently executed published UMD build.
    original_calls=list(calls)
    selected=[3,4,8,11,15,19,21,25]
    for i in selected:
        call=dict(original_calls[i])
        call['module']='driver-ts.cjs' if call['module']=='driver.cjs' else 'codec/src/sourcemap-codec.ts'
        calls.append(call); expected.append(expected[i])
    for i in (3,11):
        call=dict(original_calls[i]);call['module']='codec/dist/sourcemap-codec.mjs'
        calls.append(call);expected.append(expected[i])
    calls_path.write_text(json.dumps(calls))
    (out/'original.json').write_text(json.dumps(expected))
    shutil.copytree(project, out/'inputs')
    files={str(p.relative_to(project)):qualification.sha(p) for p in project.rglob('*') if p.is_file()}
    code=[*sorted((ROOT/'bridge/marvosa/transcription').glob('*.py')),ROOT/'bridge/marvosa/rea_hcl.py',ROOT/'src/domain/hclTranscription.ts',ROOT/'src/generatedPackageMetadata.ts']
    manifest={'package':'@jridgewell/sourcemap-codec','version':'1.6.0','files_sha256':files,
              'input_file_count':len(files),'input_bytes':sum(p.stat().st_size for p in project.rglob('*') if p.is_file()),
              'implementation_sha256':{str(p.relative_to(ROOT)):qualification.sha(p) for p in code},
              'whole_real_map':{'path':str(source_map.relative_to(ROOT)), 'sha256':qualification.sha(source_map),'bytes':source_map.stat().st_size,
                'generated_lines':len(mappings.split(';')),'segments':sum(len(l.split(',')) for l in mappings.split(';') if l)},
              'scope':'Complete published UMD module and five original TypeScript source modules; all eight exports exercised. ESM encode/decode also executed. Node oracle is the published UMD build.',
              'external_model_calls':0,'model_tokens':'Not applicable; no external model', 'simultaneous_process_family_peak_memory':'not measured'}
    (out/'input-manifest.json').write_text(json.dumps(manifest,indent=2))
    for p in code:
        d=out/'executed-source'/p.relative_to(ROOT);d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,d)
    report, raw, metrics=qualification.cli(out,'codec','hcl-transcribe',str(project),'--calls',json.dumps(calls))
    report=report['normalized_result'];compare(report,expected)
    assert report['working_memory']['source_regeneration_verified']
    target_unknowns=[u for u in report['analysis']['unknowns'] if u['id'].startswith(('codec/dist/sourcemap-codec.umd.js:', 'codec/dist/sourcemap-codec.mjs:', 'codec/src/', 'driver.cjs:', 'driver-ts.cjs:'))]
    assert not target_unknowns,target_unknowns
    graph=out/'codec.hcl.json';graph.write_text(json.dumps(report['program'],separators=(',',':')))
    record={'comparisons':len(calls),'matched':len(calls),'distributions':{'UMD':28,'TypeScript':8,'ESM':2},'real_map':manifest['whole_real_map'],'coverage':report['coverage'],
            'target_unknown_syntax':0,'executed_nodes':len(report['execution']['executed_nodes']),
            'hcl_generators':report['execution']['generator_count'],'metrics':metrics}
    (out/'summary.json').write_text(json.dumps(record,indent=2))
    qualification.archive(raw)
    # Independent process, supplied source tree absent. One non-empty public task.
    hidden=project.with_name('inputs-unavailable');project.rename(hidden)
    try:
        assert not project.exists()
        replay, replay_raw, replay_metrics=qualification.cli(out,'saved','hcl-run',str(graph),'--calls',json.dumps([calls[real_map_call_index]]))
        assert not project.exists()
    finally:
        hidden.rename(project)
    compare(replay['normalized_result'],[expected[real_map_call_index]])
    qualification.archive(replay_raw)
    record.update(saved_graph_without_sources='passed',saved_metrics=replay_metrics)
    (out/'summary.json').write_text(json.dumps(record,indent=2))
    print(json.dumps(record),flush=True)

if __name__=='__main__':main()
