# Object and module qualification

`verify.py` runs the production REA CLI against the complete unchanged `@jridgewell/sourcemap-codec` package and its original TypeScript modules. The complete `resolve-uri` source map contributes 1,014 mappings, all decoded and re-encoded. Original Node executions provide expected outputs. The driver files only prepare public argument shapes and invoke original codec exports.

The supplied `results/qualification/` records 38 matched comparisons, complete source and implementation hashes, the executable graph, full native braids compressed with gzip and an independent replay while the original temporary source directory is absent. `results/regression/` records the repeated 295 Base64/Pako/CPython comparisons. `results/language-controls/` separately records 20 Node comparisons and two unsupported-boundary checks; these controls are not counted as open-source project proof.

```sh
python3 experiments/marvosa-objects/verify.py --output /absolute/new/result-directory
python3 experiments/marvosa-objects/verify_semantics.py /absolute/new/control-directory
```

Each output directory must be new. Input files remain whole; the temporary input directory permits a real source-unavailable replay without modifying installed dependencies. Saved source snapshots and the native pins identify the implementation actually executed. Read `docs/hcl-objects.md` for feature coverage, observed costs and unimplemented semantics.
