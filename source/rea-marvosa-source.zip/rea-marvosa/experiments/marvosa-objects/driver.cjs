'use strict';
// Verification boundary only: construct the package's documented array shapes.
// Every codec algorithm below is the complete, unchanged installed OSS module.
const codec = require('./codec/dist/sourcemap-codec.umd.js');
exports.originalScopes = function (specs) {
  const scopes = [];
  for (const spec of specs) {
    const scope = spec.range.slice();
    scope.vars = spec.vars;
    scopes.push(scope);
  }
  const encoded = codec.encodeOriginalScopes(scopes);
  return { encoded, decoded: codec.decodeOriginalScopes(encoded) };
};
exports.generatedRanges = function (specs) {
  const ranges = [];
  for (const spec of specs) {
    const range = spec.range.slice();
    range.isScope = spec.isScope;
    range.callsite = spec.callsite;
    range.bindings = spec.bindings;
    ranges.push(range);
  }
  const encoded = codec.encodeGeneratedRanges(ranges);
  return { encoded, decoded: codec.decodeGeneratedRanges(encoded) };
};
