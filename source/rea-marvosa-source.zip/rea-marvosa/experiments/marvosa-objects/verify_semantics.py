#!/usr/bin/env python3
"""Public CLI versus Node controls for object semantics; separate from OSS proof."""
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import shutil
import tempfile

ROOT=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('objects',Path(__file__).with_name('verify.py'))
objects=importlib.util.module_from_spec(spec);spec.loader.exec_module(objects)
out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=False)
names=['methods','descriptors','destructure','views','utf16','enumeration','sorting','namedArrays','fields','loneSurrogates','defaultsOnce',
       'constError','thisError','readonlyError','descriptorError','classTdzError','forTdzError']
calls=[{'module':'semantics.cjs','entry':n} for n in names]
calls += [{'module':'modules/use.mjs','entry':'observe'}]*2+[{'module':'modules/use.mjs','entry':'importedWrite'}]
node_code=r'''
(async()=>{const m=require(process.argv[1]),e=await import(process.argv[2]);
function project(v){if(v===undefined)return {type:'undefined'};if(Array.isArray(v)){const items=v.map(project),p={};for(const k of Object.keys(v))if(!/^(0|[1-9][0-9]*)$/.test(k))p[k]=project(v[k]);return Object.keys(p).length?{type:'array',items,properties:p}:items;}if(v && typeof v==='object')return ArrayBuffer.isView(v)?Array.from(v):Object.fromEntries(Object.entries(v).map(([k,x])=>[k,project(x)]));return v;}
const names=JSON.parse(process.argv[3]);let out=names.map(n=>{try{return {value:project(m[n]())};}catch(e){return {error:true};}});
for(const n of ['observe','observe','importedWrite']){try{out.push({value:project(e[n]())});}catch(e){out.push({error:true});}}
console.log(JSON.stringify(out));})();'''
expected=json.loads(subprocess.check_output(['node','-e',node_code,str(Path(__file__).with_name('semantics.cjs')),
                  (Path(__file__).parent/'modules/use.mjs').as_uri(),json.dumps(names)]))
(out/'original.json').write_text(json.dumps(expected));(out/'calls.json').write_text(json.dumps(calls))
# noHost is never invoked by the Node oracle; it is a graph-only refusal check.
calls += [{'module':'semantics.cjs','entry':'noHost'},{'module':'semantics.cjs','entry':'inheritance'}]
source_owner=tempfile.TemporaryDirectory(prefix='rea-hcl-object-controls-')
source=Path(source_owner.name)
shutil.copy2(Path(__file__).with_name('semantics.cjs'),source/'semantics.cjs')
shutil.copytree(Path(__file__).parent/'modules',source/'modules')
shutil.copytree(source,out/'inputs')
evidence,raw,metrics=objects.qualification.cli(out,'semantics','hcl-transcribe',str(source),'--calls',json.dumps(calls))
actual=evidence['normalized_result']['execution']['calls']
for call,wanted in zip(actual,expected):
 if wanted.get('error'):assert call['status']=='error',(call['entry'],call.get('error'))
 else:assert call['status']=='completed' and objects.decode(call['value'])==wanted['value'],(call['entry'],call.get('error'),objects.decode(call.get('value')),wanted)
for call in actual[-2:]:assert call['status']=='unsupported',call
objects.qualification.archive(raw)
summary={'node_comparisons':len(expected),'matched':len(expected),'unsupported_checks':2,'metrics':metrics}
(out/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary))
