'use strict';
exports.methods = function () {
  class Counter {
    constructor(v) { this.v = v; }
    add(v) { this.v += v; return this.v; }
    closure() { return () => this.v; }
    static twice(v) { return v * 2; }
  }
  const a = new Counter(3), b = new Counter(10);
  const add = a.add;
  const one = a.add(4), two = add.call(b, 5), three = add.apply(a, [2]);
  const closure = a.closure();
  return [one, two, three, closure.call(b), Counter.twice(4), a.add === b.add];
};
exports.descriptors = function () {
  const obj = { n: 4 };
  Object.defineProperty(obj, 'double', { get() { return this.n * 2; }, set(v) { this.n = v / 2; }, enumerable: true });
  obj.double = 20;
  const value = obj.double;
  const desc = Object.getOwnPropertyDescriptor(obj, 'double');
  return [value, obj.n, desc.enumerable, desc.configurable, Object.keys(obj), Object.getOwnPropertyNames(obj), Object.prototype.hasOwnProperty.call(obj, 'double')];
};
exports.destructure = function () {
  const data = { outer: { a: 3 }, v: [7, 8] };
  const { outer: { a }, v: [b, c], missing = 5 } = data;
  let x, y;
  ({ outer: { a: x }, absent: y = 9 } = data);
  let total = 0;
  for (const [left, right] of [[1, 2], [3, 4]]) total += left + right;
  function f(v = 11) { return v; }
  return [a, b, c, missing, x, y, total, f(undefined)];
};
exports.views = function () {
  const data = new Uint8Array([1, 2, 3, 4]);
  const view = data.subarray(1, 3);
  view[0] = 255;
  data[2] = 19;
  const copy = view.slice();
  copy[0] = 20;
  data.set(data.subarray(0, 3), 1);
  return [data, view, copy];
};
exports.utf16 = function () {
  const s = 'A😀B';
  return [s.length, s.indexOf('B'), s.indexOf('😀'), s.slice(1, 3), s.charCodeAt(1), s.charCodeAt(2), String.fromCharCode(55357, 56832), s.split('').length];
};
exports.enumeration = function () {
  const data = { z: 1, 2: 2, 1: 3, a: 4 };
  Object.defineProperty(data, 'hidden', {value: 17});
  const keys = [];
  for (const key in data) keys.push(key);
  return [keys, Object.keys(data), Object.getOwnPropertyNames(data), 'hidden' in data];
};
exports.sorting = function () {
  const rows = [[3, 'x'], [1, 'a'], [1, 'b'], [2, 'y']];
  rows.sort((a, b) => a[0] - b[0]);
  return rows;
};
exports.namedArrays = function () {
  const a = [1, 2]; a.label = 'source'; a.vars = [3, 4]; return a;
};
exports.constError = function () { const {x} = {x:1}; x=2; };
exports.thisError = function () { class C { value() { return this.x; } } const f = new C().value; return f(); };
exports.readonlyError = function () { const o={};Object.defineProperty(o,'x',{value:1});o.x=2; };
exports.descriptorError = function () { const o={};Object.defineProperty(o,'x',{value:1});Object.defineProperty(o,'x',{value:2}); };
exports.classTdzError = function () { return new C(); class C {} };
exports.noHost = function () { return require('node:fs').readFileSync('/etc/passwd'); };
exports.inheritance = function () { class C extends Array {} return new C(); };

exports.fields = function () {
  class C { x = 3; y = this.x + 2; read = () => this.x; static offset = 7; static plus(v) { return this.offset + v; } }
  const a = new C(), b = new C();
  a.x = 11;
  return [a.y, b.x, a.read(), b.read(), C.plus(2)];
};
exports.forTdzError = function () { const i=3; for(let i=i; i<4;i++) {} };
exports.loneSurrogates = function () { return ['😀'.slice(0,1), String.fromCharCode(56832), '\ud800', '\ud800'.indexOf('x')]; };

exports.defaultsOnce = function () {
  let calls = 0;
  function side() { calls++; return undefined; }
  function f(value = side()) { return calls; }
  return [f(), f(undefined), calls];
};
