import { count, increment } from './reexport.mjs';
export function observe() { const before = count; increment(); return [before, count]; }
export function importedWrite() { count = 7; }
