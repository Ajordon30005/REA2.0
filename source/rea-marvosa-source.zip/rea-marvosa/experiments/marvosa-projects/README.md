# Whole-package qualification

`verify.py` uses the complete unchanged Pako package and actual published/project documents. It invokes normal package exports through the public HCL workflow API, with no target-specific production driver. Node supplies the independent original outputs; Python zlib also decodes the real compressed files. The emitted graph is saved and replayed while the original source directory is absent.

`verify_controls.py` separately checks package resolution, source constructors/prototypes, labeled control flow, exceptions, typed buffers, and result-reference errors against Node. These controls supplement the unchanged-package evidence.

```sh
python3 experiments/marvosa-projects/verify.py --output /absolute/new/qualification
python3 experiments/marvosa-projects/verify_controls.py /absolute/new/controls
node scripts/verify-marvosa-transcription.mjs
```

`npm run verify:marvosa-projects` creates a fresh dated results directory. The
captured qualification retains its exact executed verifier; the shipped runner
also releases its already-archived first response before starting the replay.

The results contain complete compressed CLI responses, saved programs, original outputs, full inputs and licenses, exact executed sources, source hashes, and whole-task measurements. Trace readers authenticate every generator and source range. `trace-memory-comparison.json` compares the same complete Rust binary workload before and after incremental trace storage, including equality of the complete packed words and all calls.

Timing includes parsing, native arithmetic, complete trace encoding, and delivery. Concurrent verification affects timing. `wait4` peak RSS is retained with its accounting limitation; it is not a simultaneous process-family measurement. These runs do not establish universal semantic coverage or a general speed advantage.
