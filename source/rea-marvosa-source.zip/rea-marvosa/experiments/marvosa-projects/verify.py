#!/usr/bin/env python3
"""Complete, unchanged Pako package: public CLI, native oracle, saved workflow.

The production path has no target-specific driver. These JSON call descriptions
are the same public workflow API available to users and MCP clients.
"""
import argparse
from datetime import datetime, timezone
import gc
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import zlib

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location("qualification", ROOT / "experiments/marvosa-transcription/verify.py")
qualification = importlib.util.module_from_spec(spec)
spec.loader.exec_module(qualification)
sys.path.insert(0, str(ROOT / "bridge/marvosa"))
from transcription.trace import unpack


def plain(value):
    if isinstance(value, dict):
        if value.get("type") == "number":
            assert int(value["integer"]) % int(value["scale"]) == 0
            return int(value["integer"]) // int(value["scale"])
        return {key: plain(item) for key, item in value.items()}
    if isinstance(value, list):
        return [plain(item) for item in value]
    return value


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path(__file__).parent / "results" /
                        ("qualification-" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")))
    out = parser.parse_args().output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    print(json.dumps({"output_directory": str(out)}), flush=True)
    source_owner = tempfile.TemporaryDirectory(prefix="rea-hcl-complete-package-")
    source = Path(source_owner.name) / "pako"
    shutil.copytree(ROOT / "node_modules/pako", source)
    shutil.copytree(source, out / "inputs/pako")
    payloads = out / "payloads"
    payloads.mkdir()
    shutil.copy2(source / "README.md", payloads / "pako-README.md")
    shutil.copy2(ROOT / "docs/architecture.mermaid", payloads / "rea-architecture.mermaid")
    readme = (source / "README.md").read_text()
    architecture = (ROOT / "docs/architecture.mermaid").read_bytes()
    index = (source / "index.js").read_bytes()
    calls = []
    def add(entry, args=None, **fields):
        calls.append({"entry": entry, "arguments_json": json.dumps(args or []), **fields})
    def ref(identity, path=None):
        return [{"index": 0, "result_id": identity, **({"path": path} if path else {})}]
    add("gzip", [readme], result_id="gzip")
    add("ungzip", [None, {"to": "string"}], arguments_from=ref("gzip"))
    add("deflateRaw", [list(architecture), {"level": 9}], result_id="raw")
    add("inflateRaw", [None], arguments_from=ref("raw"))
    add("deflate", [list(index), {"dictionary": readme}], result_id="dictionary")
    add("inflate", [None, {"dictionary": readme}], arguments_from=ref("dictionary"))
    add("gzip", [list(index), {"header": {"name": "index.js", "comment": "REA HCL package", "extra": [1, 2, 3], "hcrc": True}}], result_id="header")
    add("ungzip", [None], arguments_from=ref("header"))
    add("Deflate", [{"gzip": True}], construct=True, result_id="stream", return_value=False)
    add("push", [readme, False], receiver_id="stream")
    add("push", [list(architecture), True], receiver_id="stream")
    add("ungzip", [None, {"to": "string"}], arguments_from=ref("stream", ["result"]))
    add("inflate", [[1, 2, 3]])
    add("deflate", [list(index), {"level": 99}])
    calls_path = out / "calls.json"
    calls_path.write_text(json.dumps(calls))
    oracle = r'''
const fs=require('fs'),m=require(process.argv[1]),calls=JSON.parse(fs.readFileSync(process.argv[2])),bound=new Map();
const results=calls.map(c=>{try{
 let args=JSON.parse(c.arguments_json);for(const b of c.arguments_from||[]){let v=bound.get(b.result_id);for(const k of b.path||[])v=v[k];args[b.index]=v;}
 const receiver=c.receiver_id?bound.get(c.receiver_id):m;
 const value=c.construct?Reflect.construct(receiver[c.entry],args):receiver[c.entry](...args);
 if(c.result_id)bound.set(c.result_id,value);
 return {status:'completed',value:c.return_value===false?{type:'reference',id:c.result_id}:ArrayBuffer.isView(value)?Array.from(value):value};
}catch(e){return {status:'error',message:String(e)};}});
console.log(JSON.stringify(results));'''
    expected = json.loads(subprocess.check_output(["node", "-e", oracle, str(source), str(calls_path)]))
    (out / "original.json").write_text(json.dumps(expected))
    assert expected[1]["value"] == readme
    assert expected[3]["value"] == list(architecture)
    assert expected[5]["value"] == expected[7]["value"] == list(index)
    assert expected[11]["value"] == readme + architecture.decode()
    assert zlib.decompress(bytes(expected[0]["value"]), wbits=31) == readme.encode()
    assert zlib.decompress(bytes(expected[2]["value"]), wbits=-15) == architecture
    implementation = [*sorted((ROOT / "bridge/marvosa/transcription").glob("*.py")), ROOT / "src/domain/marvosa.ts",
                      ROOT / "src/domain/hclTranscription.ts", ROOT / "src/marvosa/MarvosaSourceInput.ts"]
    manifest = {"files": {str(p.relative_to(source)): qualification.sha(p) for p in sorted(source.rglob("*")) if p.is_file()},
                "implementation_sha256": {str(p.relative_to(ROOT)): qualification.sha(p) for p in implementation},
                "payloads": {p.name: {"bytes": p.stat().st_size, "sha256": qualification.sha(p)} for p in payloads.iterdir()},
                "node": subprocess.check_output(["node", "--version"], text=True).strip(), "python": sys.version}
    (out / "manifest.json").write_text(json.dumps(manifest, indent=2))
    for path in implementation:
        target = out / "executed-source" / path.relative_to(ROOT)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, target)

    def verify(report):
        actual = report["execution"]["calls"]
        assert len(actual) == len(expected)
        for i, (call, wanted) in enumerate(zip(actual, expected)):
            assert call["status"] == wanted["status"], (i, call.get("error"), wanted)
            if wanted["status"] == "completed":
                assert plain(call["value"]) == wanted["value"], (i, "output differs")
        for field in ("braid", "braid_sources"):
            trace = report["execution"][field]
            count = sum(1 for _ in unpack(trace))
            assert count == trace["record_count"]
        return {"calls": len(actual), "matched": len(actual), "generators": report["execution"]["generator_count"],
                "executed_nodes": len(report["execution"]["executed_nodes"]),
                "trace": {key: value for key, value in report["execution"]["braid"].items() if key != "base64"},
                "encoded_trace_bytes": len(report["execution"]["braid"]["base64"])}

    evidence, raw, metrics = qualification.cli(out, "package", "hcl-transcribe", str(source), "--calls", json.dumps(calls))
    report = evidence["normalized_result"]
    summary = verify(report)
    summary.update(metrics=metrics, coverage=report["coverage"], project=report["program"]["project"])
    assert report["program"]["project"]["entry_module"] == "index.js"
    assert report["working_memory"]["source_regeneration_verified"]
    program = out / "package.hcl.json"
    program.write_text(json.dumps(report["program"], separators=(",", ":")))
    qualification.archive(raw)
    # The complete first response is safely retained. Keep only its summary
    # while the independent replay runs, rather than a second in-memory copy.
    del report, evidence
    gc.collect()
    unavailable = source.with_name("original-input-unavailable")
    source.rename(unavailable)
    try:
        replay, raw, replay_metrics = qualification.cli(out, "saved", "hcl-run", str(program), "--calls", json.dumps(calls))
    finally:
        unavailable.rename(source)
    summary["saved_source_absent"] = verify(replay["normalized_result"])
    summary["saved_metrics"] = replay_metrics
    qualification.archive(raw)
    (out / "summary.json").write_text(json.dumps(summary, indent=2))
    print(json.dumps({key: value for key, value in summary.items() if key != "project"}), flush=True)


if __name__ == "__main__":
    main()
