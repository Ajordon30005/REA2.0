#!/usr/bin/env python3
"""Node comparisons for workflow and language boundaries, separate from OSS proof."""
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location("projects", Path(__file__).with_name("verify.py"))
projects = importlib.util.module_from_spec(spec)
spec.loader.exec_module(projects)
out = Path(sys.argv[1]).resolve()
out.mkdir(parents=True, exist_ok=False)
owner = tempfile.TemporaryDirectory(prefix="hcl-project-controls-")
source = Path(owner.name)
files = {
    "package.json": json.dumps({"main": "lib/start.cjs"}),
    "lib/collision.js": "module.exports=11;",
    "lib/collision/index.js": "module.exports=99;",
    "node_modules/dep/package.json": json.dumps({"main": "body.js"}),
    "node_modules/dep/body.js": "module.exports=37;",
    "lib/node_modules/dep/package.json": json.dumps({"main": "inner.cjs"}),
    "lib/node_modules/dep/inner.cjs": "module.exports=17;",
    "lib/data.json": '{"value":137}',
    "lib/start.cjs": r'''"use strict";
exports.resolution=function(){return [require('./collision'),require('dep'),require('./data.json').value];};
exports.constructors=function(){
 function Counter(v){this.v=v;}
 Counter.prototype.add=function(v){this.v+=v;return this.v;};
 Counter.tag=7;
 const a=new Counter(2),b=new Counter(10);
 function ReturnObject(){return {x:19};}
 function ReturnScalar(){this.x=23;return 8;}
 return [a.add(3),a.add===b.add,a instanceof Counter,b instanceof Counter,
         new ReturnObject().x,new ReturnScalar().x,Counter.tag,a.constructor===Counter];
};
exports.labels=function(){
 let total=0;
 outer: for(let i=0;i<5;i++) {
   for(let j=0;j<4;j++){if(j===2)continue outer;total+=i+j;}
 }
 block: { total+=10;break block;total=999; }
 outer2: for(let i=0;i<4;i++){switch(i){case 2:break outer2;default:total+=3;}}
 return total;
};
exports.exceptions=function(){
 let count=0;
 function a(){try{throw {x:7};}catch(e){return e.x;}finally{count++;}}
 function b(){try{return 2;}finally{return 9;}}
 return [a(),b(),count];
};
exports.finallyLoop=function(){let sum=0;for(let i=0;i<4;i++){try{if(i===1)continue;if(i===3)break;sum+=i;}finally{sum+=10;}}return sum;};
exports.buffers=function(){const a=new Uint16Array([65535,65536,-1]);const b=new Int16Array([65535,32768,-32769]);return [a,b,Object.prototype.toString.call(a),Array.isArray(a),Array.isArray([]),~~true,~~undefined];};
exports.arrays=function(){const a=[1,2,3];a.length=2;const b=Array.prototype.slice.call(a,1);return [b,a.shift(),a.length];};
exports.catchBinding=function(){try{throw 137;}catch(e){return e+1;}};
exports.unresolvedFinally=function(){try{return require('node:fs');}catch(e){return 1;}finally{return 2;}};
exports.forward=function(x){return x;};
''',
}
for name, content in files.items():
    target = source / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(content)
shutil.copytree(source, out / "inputs")
names = ["resolution", "constructors", "labels", "exceptions", "finallyLoop", "buffers", "arrays", "catchBinding"]
oracle = r'''const m=require(process.argv[1]),names=JSON.parse(process.argv[2]);function p(v){if(ArrayBuffer.isView(v))return Array.from(v);if(Array.isArray(v))return v.map(p);return v;}console.log(JSON.stringify(names.map(n=>p(m[n]()))));'''
expected = json.loads(subprocess.check_output(["node", "-e", oracle, str(source), json.dumps(names)]))
calls = [{"entry": name} for name in names] + [
    {"entry": "unresolvedFinally"},
    {"entry": "forward", "arguments_json": "[null]", "arguments_from": [{"index": 0, "result_id": "absent"}]},
    {"entry": "forward", "arguments_json": "[137]", "result_id": "result"},
    {"entry": "forward", "arguments_json": "[9]", "result_id": "result"},
    {"entry": "forward", "arguments_json": "[null]", "arguments_from": [{"index": 0, "result_id": "result"}]},
]
(out / "calls.json").write_text(json.dumps(calls))
(out / "original.json").write_text(json.dumps(expected))
evidence, raw, metrics = projects.qualification.cli(out, "controls", "hcl-transcribe", str(source), "--calls", json.dumps(calls))
report = evidence["normalized_result"]
actual = report["execution"]["calls"]
for i, wanted in enumerate(expected):
    assert actual[i]["status"] == "completed", (names[i], actual[i].get("error"))
    assert projects.plain(actual[i]["value"]) == wanted, (names[i], projects.plain(actual[i]["value"]), wanted)
assert [call["status"] for call in actual[-5:]] == ["unsupported", "error", "completed", "error", "completed"]
assert projects.plain(actual[-1]["value"]) == 137
assert report["program"]["project"]["entry_module"] == "lib/start.cjs"
projects.qualification.archive(raw)
summary = {"node_comparisons": len(expected), "matched": len(expected), "workflow_failure_controls": 5, "metrics": metrics}
(out / "summary.json").write_text(json.dumps(summary, indent=2))
print(json.dumps(summary), flush=True)
