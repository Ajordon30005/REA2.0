# Real HCL transcription qualification

`verify.py` invokes the compiled production REA CLI on complete, unchanged open-source source files. It compares automatically emitted HCL execution against the originals and independent Base64 expectations. No target-specific translator, mocked provider or precomputed expected output is installed in the product.

```sh
python3 experiments/marvosa-transcription/verify.py --output /absolute/new/results
node scripts/verify-marvosa-transcription.mjs
```

The supplied `results/qualification-final/` contains:

- `input-manifest.json`: exact source, implementation and engine-context identities.
- `*.calls.json`, `*.original.json`: real inputs and independent oracle outputs.
- `*.hcl.json`: complete emitted, independently executable graph artifacts.
- `*.json.gz`: complete production CLI responses, including every HCL operation in the braid. Decompress with Python's `gzip` module or `gzip -dk`.
- `summary.json` and `*.metrics.json`: observed comparisons and whole-command timings.
- `mcp.json`: actual stdio MCP, CLI/MCP identity parity, tamper rejection and real CRC cancellation.

There are 295 primary comparisons: 28 successful exact Base64 results, one matching source error, eight exact checksum results and 258 color conversions within `1e-14` of CPython. Three further separate-process calls run the saved graphs while the selected source paths are unavailable, using the complete repository manifest for the Base64 and checksum replays.

This establishes the recorded source modules and paths, not universal source-language support, novel native-AI reasoning, or a speed advantage. Full traces increase the delivered bytes. The guide at `docs/hcl-transcription.md` explains the current boundaries, host control responsibilities and finite-precision semantics.
