#!/usr/bin/env python3
"""Actual REA CLI against unchanged installed OSS modules and independent oracles.

No injected provider and no expected-output implementation inside the transcriber.
Complete CLI results, including all braids, are retained as gzip JSON. Runtime
source imports below are confined to this explicitly invoked verification oracle.
"""
import argparse
import base64
import colorsys
import gzip
import hashlib
import json
import os
from pathlib import Path
import platform
import random
import shutil
import subprocess
import sys
import tempfile
import time
from decimal import Decimal


ROOT = Path(__file__).resolve().parents[2]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def decode(value):
    if isinstance(value, dict) and value.get("type") == "number":
        return Decimal(value["decimal"])
    if isinstance(value, list):
        return [decode(item) for item in value]
    return value


def cli(directory, name, command, *args):
    if command == "hcl-transcribe":
        args = (*args, "--verify-memory")
    output = directory / (name + ".json")
    stderr = directory / (name + ".stderr")
    started = time.monotonic()
    with output.open("wb") as out, stderr.open("wb") as err:
        child = subprocess.Popen(["node", str(ROOT / "scripts/rea.mjs"), command, *args, "--json"],
                                 cwd=ROOT, stdout=out, stderr=err)
        _, status, usage = os.wait4(child.pid, 0)
        child.returncode = os.waitstatus_to_exitcode(status)
    elapsed = time.monotonic() - started
    receipt = {"exit_code": child.returncode, "wall_seconds": elapsed,
               "cpu_seconds": usage.ru_utime + usage.ru_stime,
               "wait4_peak_rss_kib": usage.ru_maxrss, "output_bytes": output.stat().st_size,
               "memory_accounting": "wait4 ru_maxrss for the waited process and reaped descendants; simultaneous process-family RSS not measured"}
    (directory / (name + ".metrics.json")).write_text(json.dumps(receipt, indent=2))
    value = json.loads(output.read_text())
    if child.returncode:
        raise AssertionError((name, value))
    return value, output, receipt


def archive(path):
    with path.open("rb") as source, gzip.open(str(path) + ".gz", "wb", compresslevel=6) as target:
        shutil.copyfileobj(source, target)
    path.unlink()


def compare_calls(report, expected, tolerance=None):
    observed = report["execution"]["calls"]
    assert len(observed) == len(expected)
    maximum = Decimal(0)
    for index, (actual, wanted) in enumerate(zip(observed, expected)):
        if isinstance(wanted, dict) and wanted.get("error"):
            assert actual["status"] == "error", (index, actual)
            continue
        assert actual["status"] == "completed", (index, actual)
        actual_value = decode(actual["value"])
        if tolerance is None:
            assert actual_value == wanted, (index, actual_value, wanted)
        else:
            assert len(actual_value) == len(wanted)
            for left, right in zip(actual_value, wanted):
                error = abs(left - Decimal(str(right)))
                maximum = max(maximum, error)
                assert error <= tolerance, (index, left, right, error)
    return str(maximum)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path(__file__).parent / "results/qualification")
    args = parser.parse_args()
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    # Keep the live input outside workspace synchronization while proving that
    # a saved graph executes with its original directory absent.
    source_owner = tempfile.TemporaryDirectory(prefix="rea-hcl-regression-")
    inputs = Path(source_owner.name) / "inputs"
    inputs.mkdir()
    shutil.copytree(ROOT / "node_modules/base64-js", inputs / "base64-js")
    checksums = inputs / "pako-checksums"
    checksums.mkdir()
    for name in ("crc32.js", "adler32.js"):
        shutil.copy2(ROOT / "node_modules/pako/lib/zlib" / name, checksums / name)
    shutil.copy2(ROOT / "node_modules/pako/LICENSE", checksums / "LICENSE")
    shutil.copy2(ROOT / "node_modules/pako/package.json", checksums / "package.json")
    shutil.copy2(colorsys.__file__, inputs / "colorsys.py")
    shutil.copy2(Path(sys.prefix) / "lib/python3.12/LICENSE.txt", inputs / "CPython-LICENSE.txt")
    shutil.copytree(inputs, out / "inputs")
    payload = (ROOT / "bridge/marvosa/UPSTREAM.json").read_bytes()
    (out / "input-manifest.json").write_text(json.dumps({
        "python": sys.version, "node": subprocess.check_output(["node", "--version"], text=True).strip(),
        "platform": platform.platform(),
        "origins": {"base64-js": "installed locked base64-js 1.5.1, MIT",
                    "pako-checksums": "installed locked pako 1.0.11, complete CRC-32 and Adler-32 modules, Zlib notices retained",
                    "colorsys": "complete installed CPython colorsys module, PSF license retained"},
        "files": {str(path.relative_to(inputs)): sha(path) for path in inputs.rglob("*") if path.is_file()},
        "real_payload": {"path": "bridge/marvosa/UPSTREAM.json", "bytes": len(payload),
                         "sha256": hashlib.sha256(payload).hexdigest()},
        "external_model_calls": 0, "model_token_usage": "not applicable; no model used",
        "implementation_sha256": {str(path.relative_to(ROOT)): sha(path) for path in
            [*sorted((ROOT / "bridge/marvosa/transcription").glob("*.py")),
             ROOT / "bridge/marvosa/rea_hcl.py", ROOT / "src/marvosa/MarvosaSourceInput.ts",
             ROOT / "src/domain/hclTranscription.ts", ROOT / "src/generatedPackageMetadata.ts"]},
    }, indent=2))

    base_calls, base_expected = [], []
    samples = [b"", b"f", b"fo", b"foo", b"foob", b"fooba", b"foobar", bytes(range(256)), payload]
    for sample in samples:
        encoded = base64.b64encode(sample).decode()
        for entry, arguments, expected in (("fromByteArray", [list(sample)], encoded),
                                            ("toByteArray", [encoded], list(sample)),
                                            ("byteLength", [encoded], len(sample))):
            base_calls.append({"module": "index.js", "entry": entry, "arguments_json": json.dumps(arguments)})
            base_expected.append(expected)
    base_calls.extend([{"module": "index.js", "entry": "toByteArray", "arguments_json": '["-_8="]'},
                       {"module": "index.js", "entry": "toByteArray", "arguments_json": '["abc"]'}])
    base_expected.extend([[251, 255], {"error": True}])
    # Also execute the original module independently through its public exports.
    oracle_js = "const m=require(process.argv[1]); const calls=JSON.parse(require('fs').readFileSync(process.argv[2])); console.log(JSON.stringify(calls.map(c=>{try{const x=m[c.entry](...JSON.parse(c.arguments_json)); return ArrayBuffer.isView(x)?Array.from(x):x;}catch(e){return {error:true};}})))"
    base_file = out / "base64.calls.json"
    base_file.write_text(json.dumps(base_calls))
    oracle = json.loads(subprocess.check_output(["node", "-e", oracle_js, str(inputs / "base64-js/index.js"), str(base_file)]))
    assert oracle == base_expected
    (out / "base64.original.json").write_text(json.dumps(oracle))

    checksum_calls = []
    for module, seed in (("crc32.js", 0), ("adler32.js", 1)):
        for sample in (b"", b"123456789", bytes(range(256)), payload):
            checksum_calls.append({"module": module, "entry": "default",
                                   "arguments_json": json.dumps([seed, list(sample), len(sample), 0])})
    checksum_file = out / "checksums.calls.json"
    checksum_file.write_text(json.dumps(checksum_calls))
    oracle_js = "const fs=require('fs'); const root=process.argv[1]; const calls=JSON.parse(fs.readFileSync(process.argv[2])); console.log(JSON.stringify(calls.map(c=>require(root+'/'+c.module)(...JSON.parse(c.arguments_json)))))"
    checksum_expected = json.loads(subprocess.check_output(["node", "-e", oracle_js, str(checksums), str(checksum_file)]))
    (out / "checksums.original.json").write_text(json.dumps(checksum_expected))

    rng = random.Random(137)
    colors = [(r, g, b) for r in (0, 1) for g in (0, 1) for b in (0, 1)]
    colors += [(0.25, 0.25, 0.25), (0.5, 0.5, 0.5), (0.75, 0.75, 0.75)]
    colors += [tuple(rng.randrange(0, 1001) / 1000 for _ in range(3)) for _ in range(32)]
    color_calls, color_expected = [], []
    for function in colorsys.__all__:
        for values in colors:
            color_calls.append({"entry": function, "arguments_json": json.dumps(values)})
            color_expected.append(list(getattr(colorsys, function)(*values)))
    (out / "colorsys.calls.json").write_text(json.dumps(color_calls))
    (out / "colorsys.original.json").write_text(json.dumps(color_expected))

    summary = []
    for name, path, calls, expected, tolerance in (
        ("base64", inputs / "base64-js", base_calls, base_expected, None),
        ("checksums", checksums, checksum_calls, checksum_expected, None),
        ("colorsys", inputs / "colorsys.py", color_calls, color_expected, Decimal("1e-14")),
    ):
        evidence, output, metrics = cli(out, name, "hcl-transcribe", str(path), "--calls", json.dumps(calls))
        report = evidence["normalized_result"]
        error = compare_calls(report, expected, tolerance)
        assert report["working_memory"]["source_regeneration_verified"]
        program_file = out / (name + ".hcl.json")
        program_file.write_text(json.dumps(report["program"], separators=(",", ":")))
        executable = [source for source in report["program"]["sources"] if source["language"] in ("javascript", "python")]
        assert all(hashlib.sha256(s["content"].encode()).hexdigest() == s["sha256"] for s in executable)
        selected_index = 24 if name == "base64" else 3 if name == "checksums" else 17
        selected_call = calls[selected_index]
        selected_expected = expected[selected_index]
        # Prove the saved graph is sufficient: the originally selected path no
        # longer exists while the separate REA hcl-run process executes it.
        unavailable = path.with_name(path.name + ".not-present-for-run")
        path.rename(unavailable)
        try:
            rerun, rerun_path, rerun_metrics = cli(out, name + "-saved", "hcl-run", str(program_file), "--calls", json.dumps([selected_call]))
        finally:
            unavailable.rename(path)
        compare_calls(rerun["normalized_result"], [selected_expected], tolerance)
        record = {"case": name, "calls": len(calls), "matched": len(calls), "maximum_absolute_error": error,
                  "tolerance": str(tolerance) if tolerance else "exact",
                  "coverage": report["coverage"], "analysis_generators": report["analysis"]["generator_count"],
                  "execution_generators": report["execution"]["generator_count"],
                  "executed_nodes": len(report["execution"]["executed_nodes"]),
                  "program_sha256": report["program_sha256"], "metrics": metrics,
                  "saved_graph_without_original_source": "passed", "saved_run_metrics": rerun_metrics}
        summary.append(record)
        (out / "summary.json").write_text(json.dumps(summary, indent=2))
        archive(output)
        archive(rerun_path)
        print(json.dumps(record), flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
